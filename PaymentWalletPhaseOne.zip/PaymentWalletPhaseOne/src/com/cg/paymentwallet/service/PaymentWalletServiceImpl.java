package com.cg.paymentwallet.service;

import java.util.ArrayList;
import java.util.Map;

import com.cg.paymentwallet.bean.PaymentWallet;
import com.cg.paymentwallet.dao.PaymentWalletDao;
import com.cg.paymentwallet.dao.PaymentWalletDaoImpl;
import com.cg.paymentwallet.exception.BalanceException;
import com.cg.paymentwallet.exception.RecordNotFoundException;



public class PaymentWalletServiceImpl implements PaymentWalletService{


		// StoreUserdata data = new StoreUserdata();// creating object for calling
		// DAO methods(storeToMap,displayDetails)
	PaymentWalletDaoImpl data = new PaymentWalletDaoImpl();

		@Override
		public boolean validateUserName(String userName) {
			if (userName.matches(USER_NAME_PATTERN))
				return true;
			else
				return false;
		}

		@Override
		public boolean validateMobile(String mobile) {
			if (mobile.matches(MOBILE_PATTERN))
				return true;
			else
				return false;
		}

		@Override
		public boolean validateEmail(String email) {
			if (email.matches(EMAIL_PATTERN))
				return true;
			else
				return false;
		}

		public boolean validateEntry(String ch) {
			if (ch.matches(ENTRY))
				return true;
			else
				return false;
		}

		public void openAccount(PaymentWallet acc) {
			data.openAccount(acc);

		}

		@Override
		public boolean validateAccId(String userAccId) {
			if (userAccId.matches(ACC_NO))
				return true;
			else
				return false;
		}

		public double showBalance(int accId) throws RecordNotFoundException {
			return data.showBalance(accId);

		}

		public boolean validateAmount(String amount) {
			if (amount.matches(AMOUNT))
				return true;
			else
				return false;
		}

		@Override
		public void deposit(int accId, double amount) throws RecordNotFoundException {
		
				data.deposit(accId, amount);
			
		}

		public void Showtransaction(int userAccId) throws RecordNotFoundException {
			data.Showtransaction(userAccId);
			
		}

		public void withdraw(int accId, double amount) throws BalanceException, RecordNotFoundException {
			
				data.withdraw(accId, amount);
			
		}

		public void fundTransfer(int source, int target, double amount) {
			try {
				data.fundTransfer(source,target,amount);
			} catch (BalanceException | RecordNotFoundException e) {
				System.out.println(e.getMessage());
			}
			
		}
	}


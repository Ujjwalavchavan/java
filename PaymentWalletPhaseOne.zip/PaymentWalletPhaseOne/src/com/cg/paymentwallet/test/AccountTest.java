package com.cg.paymentwallet.test;


import static org.junit.Assert.*;

import java.util.Map;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;



import com.cg.paymentwallet.bean.PaymentWallet;
import com.cg.paymentwallet.dao.PaymentWalletDaoImpl;
import com.cg.paymentwallet.exception.BalanceException;
import com.cg.paymentwallet.exception.RecordNotFoundException;

public class AccountTest {

	
		PaymentWalletDaoImpl accountDao = null;

		@Before
		public void setUp() throws Exception {

			accountDao = new PaymentWalletDaoImpl();
		}

		@After
		public void tearDown() throws Exception {
			accountDao = null;
		}

		@Test
		public void testShowbalanceValidDetails() {
			PaymentWallet acc=new PaymentWallet("Mayuresh", 9167968584L, "Shinde@gmail.com");
			accountDao.openAccount(acc);
			try {
				double amount = accountDao.showBalance(acc.getAccNo());
				Assert.assertNotNull(amount);
			} catch (RecordNotFoundException e) {
				System.out.println(e);
			}
		}
		@Test
		public void testShowbalanceInvalidDetails() {
			PaymentWallet acc=new PaymentWallet("Mayuresh", 9167968584L, "Shinde@gmail.com");
			accountDao.openAccount(acc);
			try {
				double amount = accountDao.showBalance(12345);
				Assert.assertNull(amount);
			} catch (RecordNotFoundException e) {
				System.out.println(e);
			}
		}
		@Test
		public void testDepositValidDetails() {
			PaymentWallet acc=new PaymentWallet("Mayuresh", 9167968584L, "Shinde@gmail.com");
			accountDao.openAccount(acc);
			try {
				double amount = acc.getBalance();
				accountDao.deposit(acc.getAccNo(), 4000);
				double upadatedAmount=acc.getBalance();
				amount+=4000;
				Assert.assertTrue(amount==upadatedAmount);;
			} catch (RecordNotFoundException e) {
				System.out.println(e);
			}
		}
		@Test
		public void testDepositInvalidDetails() {
			PaymentWallet acc=new PaymentWallet("Mayuresh", 9167968584L, "Shinde@gmail.com");
			accountDao.openAccount(acc);
			try {
				double amount = acc.getBalance();
				accountDao.deposit(acc.getAccNo(), 4000);
				Assert.assertFalse(amount==amount+2000);
			} catch (RecordNotFoundException e) {
				System.out.println(e);
			}
		}
		@Test
		public void testWithdrawValidDetails() {
			PaymentWallet acc=new PaymentWallet("Mayuresh", 9167968584L, "Shinde@gmail.com");
			accountDao.openAccount(acc);
			try {
				double amount = acc.getBalance();
				accountDao.withdraw(acc.getAccNo(), 4000);
				double upadatedAmount=acc.getBalance();
				amount-=4000;
				Assert.assertTrue(amount==upadatedAmount);;
			} catch (RecordNotFoundException | BalanceException e) {
				System.out.println(e);
			}
		}
		@Test
		public void testWithdrawInvalidDetails() {
			PaymentWallet acc=new PaymentWallet("Mayuresh", 9167968584L, "Shinde@gmail.com");
			accountDao.openAccount(acc);
			try {
				double amount = acc.getBalance();
				accountDao.deposit(acc.getAccNo(), 4000);
				Assert.assertFalse(amount==amount-2000);
			} catch (RecordNotFoundException e) {
				System.out.println(e);
			}
		}
	}

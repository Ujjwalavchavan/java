package com.cg.paymentwallet.dao;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;

import com.cg.paymentwallet.bean.PaymentWallet;
import com.cg.paymentwallet.exception.BalanceException;
import com.cg.paymentwallet.exception.RecordNotFoundException;

public interface PaymentWalletDao {


	
		int MIN_BALANCE = 0;

		// creating methods for override
		void openAccount(PaymentWallet paymentWallet);

		double showBalance(int accId) throws RecordNotFoundException;

		void deposit(int accID, double amount) throws RecordNotFoundException;

		void Showtransaction(int userAccId) throws RecordNotFoundException;

		void withdraw(int accId, double amount) throws BalanceException, RecordNotFoundException;

		void fundTransfer(int source, int target, double amount) throws BalanceException, RecordNotFoundException;
	}


package com.cg.paymentwallet.exception;

	public class RecordNotFoundException extends Exception {
		public RecordNotFoundException() {
		}
		public RecordNotFoundException(String msg) {
			super(msg);
		}
	}

package com.cg.paymentwallet.ui;
import java.util.Scanner;

import com.cg.paymentwallet.bean.PaymentWallet;
import com.cg.paymentwallet.service.PaymentWalletServiceImpl;
import com.cg.paymentwallet.bean.Transaction;
import com.cg.paymentwallet.exception.BalanceException;
import com.cg.paymentwallet.exception.RecordNotFoundException;
public class ExecuterMain {

	public static void main(String[] args) {
		String ch;
		boolean isValid;
		String name;
		String email;
		String mobile;
		String userAccId;
		String amount;
		String sourceAccId;
		String targetAccId;
		PaymentWalletServiceImpl userInput = new PaymentWalletServiceImpl();
		System.out.println("kotak Bank Welcome you");
		Scanner sc = new Scanner(System.in);
		while (true) {
			while (true) {

				System.out
						.println("1.	Create Account\n2.	Show Balance\n3.	Deposite\n4.	Withdraw"
								+ "\n5.	Fund Transfer\n6.	Show Transaction\n7.	Exit");
				ch = sc.next();
				isValid = userInput.validateEntry(ch);
				if (isValid)
					break; // if user enter valid input then break
				else
					System.out.println("Please enter Valid Choice 1 or 6");
			}
			switch (ch) {
			case "1":
				System.out.println("Welcome");
				while (true) {

					System.out.println("Enter name");
					name = sc.next();

					// to validate UserName
					isValid = userInput.validateUserName(name);
					if (isValid)
						break; // if user enter valid input then break
					else
						System.out
								.println("Please enter Valid Name.\nName should have minimum 1 or max 10 character \nFirst letter must be capital");
				}
				while (true) {

					System.out.println("Enter Email");
					email = sc.next();
					// to Validate User Email

					isValid = userInput.validateEmail(email);
					if (isValid)
						break;// if user enter valid input then break
					else
						System.out
								.println("Please enter Valid Email(eg abc@gmail.com)");
				}
				while (true) {

					System.out.println("Enter mobile");
					mobile = sc.next();
					// to validate user Mobile No
					isValid = userInput.validateMobile(mobile);
					if (isValid)
						break;// if user enter valid input then break
					else
						System.out
								.println("Please enter Valid Mobile without +91 (eg. 9167968584)");
				}
				PaymentWallet acc = new PaymentWallet(name, Long.parseLong(mobile), email);
				userInput.openAccount(acc);
				System.out.println(acc);
				break;
			case "2":
				while (true) {
					System.out.println("Enter Account Id");
					userAccId = sc.next();
					isValid = userInput.validateAccId(userAccId);
					if (isValid)
						break; // if user enter valid input then break
					else
						System.out
								.println("Please enter Valid Account Id eg.1234567");
				}
				try {
					System.out
							.println("Your Blanace is "
									+ userInput.showBalance(Integer
											.parseInt(userAccId)));
				} catch (RecordNotFoundException e) {
					System.out.println(e);
				}
				break;
			case "3":
				while (true) {
					System.out.println("Enter Account Id");
					userAccId = sc.next();
					isValid = userInput.validateAccId(userAccId);
					if (isValid)
						break; // if user enter valid input then break
					else
						System.out
								.println("Please enter Valid Account Id eg.1234567");
				}
				while (true) {
					System.out.println("Enter Amount");
					amount = sc.next();
					isValid = userInput.validateAmount(amount);
					if (isValid)
						break; // if user enter valid input then break
					else
						System.out.println("Please enter Amount eg.4000");
				}
				try {
					userInput.deposit(Integer.parseInt(userAccId),
							Double.parseDouble(amount));
					System.out.println("Transaction Successful");
				} catch (RecordNotFoundException e) {
					System.out.println(e);
				}

				break;
			case "4":
				while (true) {
					System.out.println("Enter Account Id");
					userAccId = sc.next();
					isValid = userInput.validateAccId(userAccId);
					if (isValid)
						break; // if user enter valid input then break
					else
						System.out
								.println("Please enter Valid Account Id eg.1234567");
				}
				while (true) {
					System.out.println("Enter Amount");
					amount = sc.next();
					isValid = userInput.validateAmount(amount);
					if (isValid)
						break; // if user enter valid input then break
					else
						System.out.println("Please enter Amount eg.4000");
				}
				try {
					userInput.withdraw(Integer.parseInt(userAccId),
							Double.parseDouble(amount));
					System.out.println("Transaction Successful");
				} catch (BalanceException
						| RecordNotFoundException e) {
					System.out.println(e);
				}
				
				break;
			case "5":
				while (true) {
					System.out.println("Enter your Account Id");
					sourceAccId = sc.next();
					isValid = userInput.validateAccId(sourceAccId);
					if (isValid)
						break; // if user enter valid input then break
					else
						System.out
								.println("Please enter Valid Account Id eg.1234567");
				}
				while (true) {
					System.out.println("Enter receipent Account Id");
					targetAccId = sc.next();
					isValid = userInput.validateAccId(targetAccId);
					if (isValid)
						break; // if user enter valid input then break
					else
						System.out
								.println("Please enter Valid Account Id eg.1234567");
				}
				while (true) {
					System.out.println("Enter Fund transfer Amount");
					amount = sc.next();
					isValid = userInput.validateAmount(amount);
					if (isValid)
						break; // if user enter valid input then break
					else
						System.out.println("Please enter Amount eg.4000");
				}
				userInput.fundTransfer(Integer.parseInt(sourceAccId),
						Integer.parseInt(targetAccId),
						Double.parseDouble(amount));
				System.out.println("Transaction Successful");
				break;
			case "6":
				while (true) {
					System.out.println("Enter Account Id");
					userAccId = sc.next();
					isValid = userInput.validateAccId(userAccId);
					if (isValid)
						break; // if user enter valid input then break
					else
						System.out
								.println("Please enter Valid Account Id eg.1234567");
				}
				try {
					userInput.Showtransaction(Integer.parseInt(userAccId));
				} catch (NumberFormatException | RecordNotFoundException e) {
					System.out.println(e);
				}
				break;
			case "7":
				System.out.println("Thanks for visiting");
				System.exit(0);
				
				break;
			default:
				break;
			}
		}
	}
}


package com.capstore.service;

import com.capstore.entity.CouponInfo;

public interface CouponService {

	public CouponInfo couponGenerate(CouponInfo c) ;

	public String sendCoupon();

}

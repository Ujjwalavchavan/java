package com.capstore.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "coupon_info")
public class CouponInfo {

	@Id
	// @GeneratedValue
	@Column(name = "coupon_id", length = 20)
	private int couponId;

	@Column(name = "coupon_code", length = 20)
	private String couponCode;

	@Column(name = "product_discount", length = 20)
	private double productDiscount;

	@Column(name = "expiry_date", length = 20)
	private String expiryDate;

	@Column(name = "is_used", length = 20)
	private boolean isUsed=false;

	public int getCouponId() {
		return couponId;
	}

	public void setCouponId(int couponId) {
		this.couponId = couponId;
	}

	public String getCouponCode() {
		return couponCode;
	}

	public void setCouponCode(String couponCode) {
		this.couponCode = couponCode;
	}

	public double getProductDiscount() {
		return productDiscount;
	}

	public void setProductDiscount(double productDiscount) {
		this.productDiscount = productDiscount;
	}

	public String getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}

	public boolean isUsed() {
		return isUsed;
	}

	public void setUsed(boolean isUsed) {
		this.isUsed = isUsed;
	}

	public CouponInfo() {
		
	}

	public CouponInfo(int couponId, String couponCode, double productDiscount, String expiryDate, boolean isUsed) {

		this.couponId = couponId;
		this.couponCode = couponCode;
		this.productDiscount = productDiscount;
		this.expiryDate = expiryDate;
		this.isUsed = isUsed;
	}

}

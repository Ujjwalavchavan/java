package com.cg;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;

import com.cg.entities.Product;

import com.cg.repo.RepoInterface;


@SpringBootApplication
@EntityScan("com.cg.entities")
public class DataBootApplication implements CommandLineRunner {

	@Autowired
	private RepoInterface repo;//injecting repo

	public static void main(String[] args) {
		SpringApplication.run(DataBootApplication.class, args);

	}

	@Override
	public void run(String... args) throws Exception {
	//		Product p = new Product();
	//		p.setName("iphone");
	//		p.setPrice(120000);
	//		repo.save(p);
		
		Product p=repo.findById(153).get();
		System.out.println(p.getName()+":"+p.getPrice());

	}

}

package com.cg.repo;

import org.springframework.data.repository.CrudRepository;

import com.cg.entities.Product;

public interface RepoInterface extends CrudRepository<Product, Integer> {

}

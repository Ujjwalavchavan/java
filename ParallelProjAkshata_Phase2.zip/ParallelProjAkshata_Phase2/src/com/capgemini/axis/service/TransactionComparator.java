package com.capgemini.axis.service;

import java.util.Comparator;

import com.capgemini.axis.bean.Transaction;

public class TransactionComparator implements Comparator<Transaction>{     //to sort a/c to amount 

	@Override																// pass object in DAO cls
	public int compare(Transaction t1, Transaction t2) {
		return (int) (t1.getAmount()-t2.getAmount());
	}

}

package com.capgemini.axis.bean;

public class Transaction {                 //attributes of transaction class

	private String mobileNo;
	private String type;
	private double amount, balance;
	
	
	//------------- creating getters setters----------//
	public String getMobileNo() {
		return mobileNo;
	}
	public String getType() {
		return type;
	}
	public double getAmount() {
		return amount;
	}
	public double getBalance() {
		return balance;
	}
	// parameterized constructor
	public Transaction(String mobileNo, String type, double amount,    //constructor
			double balance) {
		super();
		this.mobileNo = mobileNo;
		this.type = type;
		this.amount = amount;
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "Transaction [mobileNo=" + mobileNo + ", type=" + type
				+ ", amount=" + amount + ", balance=" + balance + "]";
	}
	
}

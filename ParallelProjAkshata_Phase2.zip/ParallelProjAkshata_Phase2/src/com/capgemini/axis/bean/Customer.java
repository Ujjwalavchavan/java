package com.capgemini.axis.bean;

public class Customer implements Comparable<Customer>  {        //creating attributes
	//public class Customer { 
	private String name; 
	private long customerId;
	private String mobileno; 
	private String email;
	private double balance;
	private String password;
	 
	
	public Customer() {     //constructor
		super();
	}

	//------------- creating getters setters----------//
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name= name;
	}
	public double getId() {   
		return customerId;
	}
	public void setId(long id) {
		this.customerId = id;
	}
	
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getMobileno() {
		return mobileno;
	}
	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	// parameterized constructor
	public Customer(String name, String email,String mobileno,      //constructor
			  String password, double balance) {
		super();
		this.name = name;
		this.mobileno = mobileno;
		this.email = email;
		this.balance = balance;
		this.password = password;
	}
	@Override
	public String toString() {
		return "Customer [name=" + name + ", customerId=" + customerId
				+ ", mobileno=" + mobileno + ", email=" + email + ", balance="
				+ balance + ", password=" + password + "]";
	}

	@Override											//for set
	public int compareTo(Customer o) {
		return name.compareTo(o.getName());
	}
	




	
}

package cg.servlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cg.bean.TrainingBean;
import cg.service.ITrainingService;
import cg.service.TrainingService;

@WebServlet("/TrainingServ")
public class TrainingServ extends HttpServlet {
	private static final long serialVersionUID = 1L;

	ITrainingService service;

	@Override
	public void init() throws ServletException {
		service = new TrainingService();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		List<TrainingBean> allTrainingData = service.showAll();
		if(request.getParameter("id")==null)
		{
		request.setAttribute("data", allTrainingData);
		request.getRequestDispatcher("Training.jsp").forward(request, response);
		}
		else
		{
			int id  =  Integer.parseInt(request.getParameter("id"));
			TrainingBean tb = allTrainingData.stream().filter(x->x.getTrainingId()==id).findFirst().get();
			
			tb = service.enroll(tb);
			response.sendRedirect("Training.jsp?enrolled="+tb.getTrainingName());
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}

}

package com.cg.project.stepdefinations;

import org.junit.Assert;
import org.junit.Before;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.project.beans.PaymentDetails;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PaymentDetailsStepDefination {

	private WebDriver driver;
	private PaymentDetails payment;

	@Before
	public void setUpStepEnv() {
		System.setProperty("webdriver.chrome.driver", "mydriver\\chromedriver.exe");
	}

	@Given("^user is on Payment Details page$")
	public void user_is_on_Payment_Details_page() throws Throwable {
		driver = new ChromeDriver();
		driver.get("file:///C:\\Users\\ujchavan\\Desktop\\ujjwala\\Module 4\\Demos\\htmlFiles/PaymentDetails.html");
		payment = new PaymentDetails();
		PageFactory.initElements(driver, payment);
	
	}

	@When("^user enters valid  payment details$")
	public void user_enters_valid_payment_details() throws Throwable {
		payment.setName("Nishitha");
		payment.setCardNumber("9928282558525");
		payment.setCvv("143");
		payment.setExpirationMonth("10");
		payment.setExpiartionYear("23");
		payment.clickPayment();
		Thread.sleep(3000);
	}

	@Then("^displays 'Conference Room Booking successfully done!!!'$")
	public void displays_Conference_Room_Booking_successfully_done() throws Throwable {
		String expectedMessage = "Conference Room Booking successfully done!!!";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
		Thread.sleep(3000);
	}

	@When("^user enters loads the page$")
	public void user_enters_loads_the_page() throws Throwable {

	}

	@Then("^valid page should open$")
	public void valid_page_should_open() throws Throwable {
		String expectedPageTitle = "Payment Details";
		String actualPageTitle = driver.getTitle();
		Assert.assertEquals(expectedPageTitle, actualPageTitle);
		driver.close();
		Thread.sleep(3000);
	}

	@When("^user enters invalid name$")
	public void user_enters_invalid_name() throws Throwable {
		payment.setName("");
		payment.clickPayment();Thread.sleep(3000);
	}

	@Then("^displays 'Please fill name'$")
	public void displays_Please_fill_name() throws Throwable {
		String expectedMessage = "Please fill the Card holder name";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();Thread.sleep(3000);
	}

	@When("^user enters invalid Debit Card Number$")
	public void user_enters_invalid_Debit_Card_Number() throws Throwable {
		payment.setName("Nishitha");
		payment.clickPayment();Thread.sleep(3000);

	}

	@Then("^displays 'Please fill Debit Card Number'$")
	public void displays_Please_fill_Debit_Card_Number() throws Throwable {
		String expectedMessage = "Please fill the Debit card Number";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();Thread.sleep(3000);
	}

	@When("^user enters invalid expiration month$")
	public void user_enters_invalid_expiration_month() throws Throwable {
		payment.setName("Nishitha");
		payment.setCardNumber("9928282558525");
		payment.setCvv("143");
		payment.setExpirationMonth("");
		payment.clickPayment();Thread.sleep(3000);
	}

	@Then("^displays 'Please fill expiration month'$")
	public void displays_Please_fill_expiration_month() throws Throwable {

		String expectedMessage = "Please fill expiration month";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();Thread.sleep(3000);
	}

	@When("^user enters invalid expiration year$")
	public void user_enters_invalid_expiration_year() throws Throwable {
		payment.setName("Nishitha");
		payment.setCardNumber("9928282558525");
		payment.setCvv("143");
		payment.setExpirationMonth("08");
		payment.setExpiartionYear("");
		payment.clickPayment();Thread.sleep(3000);
	}

	@Then("^displays 'Please fill expiration year'$")
	public void displays_Please_fill_expiration_year() throws Throwable {
		String expectedMessage = "Please fill the expiration year";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();Thread.sleep(3000);
	}

}
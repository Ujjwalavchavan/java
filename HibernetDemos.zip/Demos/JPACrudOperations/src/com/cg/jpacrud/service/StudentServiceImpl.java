package com.cg.jpacrud.service;

import com.cg.jpacrud.dao.StudentDao;
import com.cg.jpacrud.dao.StudentDaoImpl;
import com.cg.jpacrud.entities.Student;

public class StudentServiceImpl implements StudentService {

	private StudentDao dao;//has a reln with dao layer

	public StudentServiceImpl() {
		dao = new StudentDaoImpl();
	}

	@Override
	public void addStudent(Student student) {
		try {
			dao.beginTransaction();
			dao.addStudent(student);
			dao.commitTransaction();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			dao.rollBackTransaction();
		}
		
	}
	
	@Override
	public void updateStudent(Student student) {
		try {
			dao.beginTransaction();
			dao.updateStudent(student);
			dao.commitTransaction();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			dao.rollBackTransaction();
		}
	}
	
	@Override
	public void removeStudent(Student student) {
		try {
			dao.beginTransaction();
			dao.removeStudent(student);
			dao.commitTransaction();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			dao.rollBackTransaction();
		}
	}
	
	@Override
	public Student findStudentById(int id) {
		//no need of transaction, as it's an read operation
		Student student  = dao.getStudentById(id);
		return student;
	}
	public void syncUpdate()
	{
		try {
			dao.beginTransaction();
			dao.syncUpdate();
			dao.commitTransaction();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			dao.rollBackTransaction();
		}
		
	}
}

package com.cg.test;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.ioc.Employee;

public class TestEmployee {
	@Test
	public void testGetObject() {

		ApplicationContext ctx = new ClassPathXmlApplicationContext("employee.xml");
		Employee e = (Employee) ctx.getBean("emp");

		assertNotNull("Null Object", e);
		System.out.println(e.toString());
	}

}

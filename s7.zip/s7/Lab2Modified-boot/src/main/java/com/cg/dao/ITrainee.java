package com.cg.dao;

import org.springframework.data.repository.CrudRepository;

import com.cg.entity.Trainee;

public interface ITrainee extends CrudRepository<Trainee, Integer> {

}

package com.cg.service;

import java.util.NoSuchElementException;

import com.cg.entity.Trainee;

public interface InterfaceTraineeService {

	void saveTrainee(Trainee t);

	Trainee getTrainee(int id);

	Iterable<Trainee> getAll();

	public String deleteTrainee(Trainee t1);

	public Trainee updateTrainee(Trainee t, int id);

}

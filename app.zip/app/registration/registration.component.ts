import { Component, OnInit } from '@angular/core';
import { EmployeeModel } from '../models/Employee';
import { EmployeeService } from '../service/employee.service';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  //storing employee data

  employee:EmployeeModel

  //initializing in constructor

  //cretaed reffrence of service
  constructor(private empservice:EmployeeService) { 
    this.employee=new EmployeeModel;
  }

  insertEmployee(){
    this.empservice.add(this.employee)

  }
  ngOnInit() {

  }

}

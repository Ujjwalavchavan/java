export class EmployeeModel
{
    public employeeid:number;
    public employeeName:string;
    public employeeSalary:number;
}
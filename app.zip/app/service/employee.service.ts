import { Injectable } from '@angular/core';
import { EmployeeModel } from '../models/Employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  //1)create an array
  empArray:EmployeeModel[];

    static counter:number=1001;
  //2)initialize using constructor
  constructor() {
    this.empArray=[];
   }

   add(employee:EmployeeModel){
     employee.employeeid=EmployeeService.counter++;
     this.empArray.push(employee);
   }

   display(){
     return this.empArray;
   }
  }

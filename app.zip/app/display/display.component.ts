import { Component, OnInit } from '@angular/core';
import { EmployeeModel } from '../models/Employee';
import { EmployeeService } from '../service/employee.service';

@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',
  styleUrls: ['./display.component.css']
})
export class DisplayComponent implements OnInit {

  //creating array
  emparray:EmployeeModel[];

  constructor(private employeeService:EmployeeService) {
    
   }

  ngOnInit() {
    this.emparray=this.employeeService.display();
  }

}

package com.capgemini.dao;

import java.util.List;
import java.util.Set;

import com.capgemini.entities.Book;

public interface AuthorBookDao {
	
	public List<Book> fetchAllBooks();
	public Set fetchBooksByAuthorName(String authorName);
	public Set fetchAuthorsByBookId(long bookId);
	public List getBooksByPriceRange();
}

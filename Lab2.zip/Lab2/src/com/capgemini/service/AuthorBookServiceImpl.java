package com.capgemini.service;

public class AuthorBookServiceImpl implements AuthorBookService {

}

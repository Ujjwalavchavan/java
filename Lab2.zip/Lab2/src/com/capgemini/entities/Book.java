package com.capgemini.entities;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import com.capgemini.entities.Author;

@Entity
@Table(name = "Book_Table")
public class Book {

	@Id
	private int ISBN;
	String title;
	double price;

	@ManyToMany(fetch=FetchType.LAZY,mappedBy="books")
	 Set<Author> authors = new HashSet<Author>();

	public Book() {
		// TODO Auto-generated constructor stub
	}

	public Book(int isbn, String title, int price) {
		super();
		ISBN = isbn;
		this.title = title;
		this.price = price;
	}

	public int getISBN() {
		return ISBN;
	}

	public void setISBN(int iSBN) {
		ISBN = iSBN;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public Set<Author> getAuthor() {
		return authors;
	}

	public void setAuthor(Set<Author> author) {
		this.authors = author;
	}

	public Set<Author> getAuthors() {
		return authors;
	}

	public void setAuthors(Set<Author> authors) {
		this.authors = authors;
	}
	public String toString() {
		return "Book [ISBN=" + ISBN + ", title=" + title + ", price=" + price
				+"]";
	}


}

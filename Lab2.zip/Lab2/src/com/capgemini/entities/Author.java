package com.capgemini.entities;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import com.capgemini.entities.Book;

@Entity
@Table(name = "Author_Table")
public class Author {
	private static final long serialVersionUID = 1L;

	@Id
	int authorId;
	String authorName;

	public Author() {
		// TODO Auto-generated constructor stub
	}

	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "Author_Book", joinColumns = { @JoinColumn(name = "authorId") }, inverseJoinColumns = { @JoinColumn(name = "ISBN") })
	Set<Book> books = new HashSet<Book>();

	public int getAuthorId() {
		return authorId;
	}

	public void setAuthorId(int authorId) {
		this.authorId = authorId;
	}

	public String getAuthorName() {
		return authorName;
	}

	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}

	public Set<Book> getBooks() {
		return books;
	}

	public void setBooks(Set<Book> book) {
		this.books = book;
	}

	public Author(String authorName, int authorId) {
		super();
		this.authorName = authorName;
		this.authorId = authorId;
	}

	public void addBooks(Book book) {
		this.getBooks().add(book);
	}

	@Override
	public String toString() {
		return "Author [authorName=" + authorName + ", authorId=" + authorId
				+ "]";
	}
}
//Package Name
package com.cg.coachingclass.stepdefinition;

//Required imports
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import com.cg.coachingclass.bean.TuitionEnquiryDetails;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TuitionEnquiryStepDefinition {

	// Creating WebDriver instance
	private WebDriver driver;
	// Declaring Bean Class Object
	private TuitionEnquiryDetails tutionEnquiryDetails;

	// To Load The Driver
	@Before
	public void setUpStepEnv() {
		System.setProperty("webdriver.chrome.driver", "mydriver\\chromedriver.exe");
	}

	// Checks Whether user is on required html page
	@Given("^User Is On Coaching_Class_Enquiry Page$")
	public void user_Is_On_Coaching_Class_Enquiry_Page() throws Throwable {
		driver = new ChromeDriver();
		driver.get("file:///C:\\Users\\ujchavan\\Desktop\\ujjwala/Coaching_Class_Enquiry.html");
		tutionEnquiryDetails = new TuitionEnquiryDetails();
		PageFactory.initElements(driver, tutionEnquiryDetails);
		Thread.sleep(1500);
	}

	// Scenario when form is completely filled
	@When("^User Complete The Form bye Entering Valid Details$")
	public void user_Complete_The_Form_bye_Entering_Valid_Details() throws Throwable {
		tutionEnquiryDetails.setFirstName("Ujjwala");
		tutionEnquiryDetails.setLastName("Chavan");
		tutionEnquiryDetails.setEmail("ujjwala@gmail.com");
		tutionEnquiryDetails.setPhoneNumber("9029519704");
		tutionEnquiryDetails.clickTuitionType();
		tutionEnquiryDetails.clickCity();
		tutionEnquiryDetails.clickModeOfLearning();
		tutionEnquiryDetails.setYourEnquiry("na");
		tutionEnquiryDetails.clickSubmitButton();
		Thread.sleep(1500);
		driver.close();
	}

	// When User Details Are Validated
	@Then("^Details Are Validated$")
	public void details_Are_Validated() throws Throwable {
		String expectedMessage = "Thank you for submitting the online coaching Class Enquiry";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		Thread.sleep(1500);
		driver.close();
	}

	// Loading The Online Coaching Class Enquiry Form
	@When("^Load Coaching_Class_Enquiry Page$")
	public void load_Coaching_Class_Enquiry_Page() throws Throwable {
		String expectedPageTitle = "Online Coaching Class Enquiry Form";
		String actualPageTitle = driver.getTitle();
		Assert.assertEquals(expectedPageTitle, actualPageTitle);
		Thread.sleep(1500);
		driver.close();
	}

	// Validating the tile is same as Online Coaching Class Enquiry Form
	@Then("^Validate Title$")
	public void validate_Title() throws Throwable {
		driver.get("Online Coaching Class Enquiry Form");
		boolean textTitle=driver.getTitle().contains("Tuition Enquiry Details Form");
		if(textTitle==false)
			System.out.println("Tuition Enquiry Details Form Text is not present");
		String title = driver.getTitle();
		if (title != "Online Coaching Class Enquiry Form") {
			driver.quit();
		}

	}

	// Methods For in valid data values
	@When("^User enters invalid first name$")
	public void user_enters_invalid_first_name() throws Throwable {
		tutionEnquiryDetails.setFirstName("");
		tutionEnquiryDetails.clickSubmitButton();
		Thread.sleep(1500);
		driver.close();
	}

	@Then("^Display First Name must be filled out$")
	public void display_First_Name_must_be_filled_out() throws Throwable {
		String expectedMessage = "First Name must be filled out";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		Thread.sleep(1500);
		driver.close();
	}

	// Methods For in valid data values
	@When("^User enters invalid last name$")
	public void user_enters_invalid_last_name() throws Throwable {
		tutionEnquiryDetails.setFirstName("Ujjwala");
		tutionEnquiryDetails.setLastName("");
		tutionEnquiryDetails.clickSubmitButton();
		Thread.sleep(1500);
		driver.close();
	}

	@Then("^Display Last Name must be filled out$")
	public void display_Last_Name_must_be_filled_out() throws Throwable {
		String expectedMessage = "Last Name must be filled out";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		Thread.sleep(1500);
		driver.close();
	}

	// Methods For in valid data values
	@When("^User enters invalid email address$")
	public void user_enters_invalid_email_address() throws Throwable {
		tutionEnquiryDetails.setFirstName("Ujjwala");
		tutionEnquiryDetails.setLastName("Chavan");
		tutionEnquiryDetails.setEmail("ytakjewsgfjdsah");
		tutionEnquiryDetails.clickSubmitButton();
		Thread.sleep(1500);
		driver.close();
	}

	@Then("^Display Email Address must be filled out$")
	public void display_Email_Address_must_be_filled_out() throws Throwable {
		String expectedMessage = "Email must be filled out";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		Thread.sleep(1500);
		driver.close();
	}

	// Methods For in valid data values
	@When("^User enters invalid mobile number$")
	public void user_enters_invalid_mobile_number() throws Throwable {
		tutionEnquiryDetails.setFirstName("Ujjwala");
		tutionEnquiryDetails.setLastName("Chavan");
		tutionEnquiryDetails.setEmail("ujjwala@gmail.com");
		tutionEnquiryDetails.clickSubmitButton();
		Thread.sleep(1500);
		driver.close();
	}

	@Then("^Display Please Enter (\\d+) Digit Numberic values only$")
	public void display_Please_Enter_Digit_Numberic_values_only(int arg1) throws Throwable {
		String expectedMessage = "Mobile must be filled out";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		Thread.sleep(1500);
		driver.close();
	}

	// When user clicks on submit button after filling all details
	@When("^User clicks on submit button$")
	public void user_clicks_on_submit_button() throws Throwable {
		tutionEnquiryDetails.setFirstName("Ujjwala");
		tutionEnquiryDetails.setLastName("Chavan");
		tutionEnquiryDetails.setEmail("ujjwala@gmail.com");
		tutionEnquiryDetails.setPhoneNumber("9029519704");
		tutionEnquiryDetails.clickTuitionType();
		tutionEnquiryDetails.clickCity();
		tutionEnquiryDetails.clickModeOfLearning();
		tutionEnquiryDetails.setYourEnquiry("na");
		tutionEnquiryDetails.clickSubmitButton();
		Thread.sleep(1500);
		driver.close();
	}

	// Displaying Message after clicking on submit button
	@Then("^Display Thank you for submitting the online coaching Class Enquiry$")
	public void display_Thank_you_for_submitting_the_online_coaching_Class_Enquiry() throws Throwable {
		driver.switchTo().alert().accept();
	}

	// Displaying Message after Form submission
	@When("^User clicks on ok$")
	public void user_clicks_on_ok() throws Throwable {
		driver.switchTo().alert().accept();
	}

	// Displaying Message
	@Then("^Display Our Counselor will contact you soon$")
	public void display_Our_Counselor_will_contact_you_soon() throws Throwable {
		driver.switchTo().alert().accept();
		driver.quit();
	}

}

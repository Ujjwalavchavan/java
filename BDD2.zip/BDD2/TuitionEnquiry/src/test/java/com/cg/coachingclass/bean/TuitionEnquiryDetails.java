//Package Name
package com.cg.coachingclass.bean;

//Required Imports
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class TuitionEnquiryDetails {

	// Mapping WebElements with members

	@FindBy(id = "fname")
	WebElement firstName;

	@FindBy(id = "lname")
	WebElement lastName;

	@FindBy(id = "emails")
	WebElement email;

	@FindBy(id = "mobile")
	WebElement phoneNumber;

	@FindBy(name = "D6")
	WebElement tuitionType;

	@FindBy(name = "D5")
	WebElement city;

	@FindBy(name = "D4")
	WebElement modeoflearning;

	@FindBy(name = "enqdetails")
	WebElement yourEnquiry;

	@FindBy(id = "Submit1")
	WebElement submitButton;

	@FindBy(id = "Submit2")
	WebElement resetButton;

	// Default Constructor
	public TuitionEnquiryDetails() {
	}

	// Getters and Setters for variables
	public String getFirstName() {
		return this.firstName.getAttribute("value");
	}

	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}

	public String getLastName() {
		return this.lastName.getAttribute("value");
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}

	public String getEmail() {
		return this.email.getAttribute("value");
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public String getPhoneNumber() {
		return this.phoneNumber.getAttribute("value");
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber.sendKeys(phoneNumber);
	}

	public String getYourEnquiry() {
		return this.yourEnquiry.getAttribute("value");
	}

	public void setYourEnquiry(String yourEnquiry) {
		this.firstName.sendKeys(yourEnquiry);
	}

	// Method to pre fill Tuition Type
	public void clickTuitionType() {
		Select select = new Select(tuitionType);
		select.selectByVisibleText("Spoken English");
	}

	// Method to pre fill City Preferences
	public void clickCity() {
		Select select = new Select(city);
		select.selectByVisibleText("Pune");
	}

	// Method to pre fill Mode Of Learning
	public void clickModeOfLearning() {
		Select select = new Select(modeoflearning);
		select.selectByVisibleText("Class rooom training");
	}

	// Method to submit the form on clicking submit button
	public void clickSubmitButton() {
		submitButton.click();
	}

	// Method to reset values of form
	public void clickResetButton() {
		resetButton.click();
	}

}

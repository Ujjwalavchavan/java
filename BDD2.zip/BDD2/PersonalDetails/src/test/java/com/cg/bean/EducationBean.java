package com.cg.bean;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class EducationBean {

	@FindBy(name="graduation")
	WebElement graduation;	
	
	@FindBy(name="percentage")
	WebElement percentage;
	
	@FindBy(name="passingyear")
	WebElement passingyear;
	
	@FindBy(name="project")
	WebElement project;
	
	@FindBy(name="technologies")
	WebElement technologies;
	
	@FindBy(name="otherTechnologies")
	WebElement otherTechnologies;
	
	@FindBy(id="btnPayment")
	WebElement paymentButton;
	
	public EducationBean() {}
	
	public String getGraduation() {
		return this.graduation.getAttribute("value");
	}

	
	public void setGraduation(String graduation) {
		this.graduation.sendKeys(graduation);
	}
	
	
	

	public String getPercentage() {
		return this.percentage.getAttribute("value");
	}
	public void setPercentage(String percentage) {
		this.percentage.sendKeys(percentage);
	}
	
	
	
	public String getPassingyear() {
		return this.passingyear.getAttribute("value");
	}
	public void setPassingyear(String passingyear) {
		this.passingyear.sendKeys(passingyear);
	}
	

	
	public String getProject() {
		return this.project.getAttribute("value");
	}
	public void setProject(String project) {
		this.project.sendKeys(project);
	}
	

	
	public String getOtherTechnologies() {
		return this.otherTechnologies.getAttribute("value");
	}
	public void setOtherTechnologies(String otherTechnologies) {
		this.otherTechnologies.sendKeys(otherTechnologies);
	}
	

	
	
	
	public void clickGraduation() {
		Select select = new Select(graduation);
		select.selectByVisibleText("IT");
	}
	
	public void clickTechnologies() {
		Select select = new Select(technologies);
		select.selectByVisibleText("java");
	}
	

		public void clickLogin() {
			paymentButton.click();
	}
}

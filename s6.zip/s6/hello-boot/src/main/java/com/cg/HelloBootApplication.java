package com.cg;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.cg")

public class HelloBootApplication implements CommandLineRunner{
	@Autowired
	private ApplicationContext ctx;
	
	
	public static void main(String[] args) {
		SpringApplication.run(HelloBootApplication.class, args);
	}


	public void run(String... args) {
		Hello h=(Hello) ctx.getBean(Hello.class);
		System.out.println(h);
		
	}

}

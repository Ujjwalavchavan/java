package com.capgemini.axis.service;

import java.util.IllegalFormatException;
import java.util.List;
import java.util.Map;

import com.capgemini.axis.bean.Customer;
import com.capgemini.axis.bean.Transaction;
import com.capgemini.axis.exception.CustomerExists;
import com.capgemini.axis.exception.CustomerNotFound;
import com.capgemini.axis.exception.IllegalFormatExecption;
import com.capgemini.axis.exception.InsufficientBalanceExeption;

public interface IService {
	 
	String userNamePattern="[a-zA-Z]{2,9}";     //Validation for name any case and can be max upto 9
	String usermobilePattern=("(0/91)?[7-9][0-9]{9}");// Validation 
	String useremailPattern="[a-zA-Z0-9+_.-]+@(.+)$";//Validation
	String userpasswordPattern="[a-zA-Z0-9,.@_]{2,8}"; 
	String userHomeChoice="[1-3]{1}";
	String userAmount="[0-9]{2,10}";
	
	 boolean validateName(String name)throws IllegalFormatExecption;             //validation for attributes
	 boolean validatemobileno(String mobileno)throws IllegalFormatExecption;
	 boolean validateemail(String email)throws IllegalFormatExecption;
	 boolean validatepassword(String password)throws IllegalFormatExecption;
	 
	 boolean validateHomeChoice(String userHChoice) throws IllegalFormatExecption;
	 boolean validateAmount(String useramt) throws IllegalFormatExecption;	 
	 
	String withdraw(Customer customer, double amount) throws InsufficientBalanceExeption;  //method used for implementation  
	String deposit(Customer customer,double amount)throws CustomerNotFound;
	String[] fundTransfer(Customer fromCust,Customer toCust,double amount) throws InsufficientBalanceExeption;
	List<Transaction> printTransaction(Customer customer);
	Customer createCustomer(Customer customer)throws CustomerExists;
	Customer checkUser(String username, String password) throws CustomerNotFound;
	
	double checkBalance(Customer customer);
	
//	Map<String, Customer> displayPersons();
	
	
//	 void storeIntoMap(Customer person);
//	 Map<String, Customer> displayPersons();
}

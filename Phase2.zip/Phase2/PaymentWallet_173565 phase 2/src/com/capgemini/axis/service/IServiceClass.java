package com.capgemini.axis.service;

import java.util.List;
import java.util.Map;

import com.capgemini.axis.bean.Customer;
import com.capgemini.axis.bean.Transaction;
import com.capgemini.axis.dao.JdbcDao;
import com.capgemini.axis.dao.IDao;
import com.capgemini.axis.exception.CustomerExists;
import com.capgemini.axis.exception.CustomerNotFound;
import com.capgemini.axis.exception.IllegalFormatExecption;
import com.capgemini.axis.exception.InsufficientBalanceExeption;

public class IServiceClass implements IService {

	//object instantiation 
	IDao CustomerDao = new JdbcDao();
	
	
	//-------validation codes------------//
	@Override
	public boolean validateName(String name) throws IllegalFormatExecption {
		if (name.matches(userNamePattern))
			return true;
		else
			throw new IllegalFormatExecption("name should be between 2 - 9 letters with 1st letter capital");		
	}

	@Override
	public boolean validatemobileno(String mobileno) throws IllegalFormatExecption {
		if (mobileno.matches(usermobilePattern))
			return true;
		else
			throw new IllegalFormatExecption("Enter Valid 10 digit mobile number.");
	}

	@Override
	public boolean validateemail(String email) throws IllegalFormatExecption {

		if (email.matches(useremailPattern))
			return true;
		else
			throw new IllegalFormatExecption("Enter Valid Email");
	}


	@Override
	public boolean validatepassword(String password) throws IllegalFormatExecption {
		if (password.matches(userpasswordPattern))
			return true;
		else
			throw new IllegalFormatExecption("Enter atleast 6-12 character");
	}

	
	@Override
	public boolean validateHomeChoice(String userHChoice) throws IllegalFormatExecption{
		if(userHChoice.matches(userHomeChoice))
			return true;
		else
			throw new IllegalFormatExecption("Please choose 1 or 2 or 3");
	}

	@Override
	public boolean validateAmount(String useramt) throws IllegalFormatExecption {
		if(useramt.matches(userAmount))
			return true;
		else
			throw new IllegalFormatExecption("Enter in numbers and should be more than Rs.10");
	}
	
	//withdraw amount
	//minimum balance should be 100
	@Override
	public String withdraw(Customer customer, double amount)throws InsufficientBalanceExeption{
		try {
			return CustomerDao.withdraw(customer, amount);
		} catch (InsufficientBalanceExeption e) {
			throw new InsufficientBalanceExeption(e.getMessage());
		}
	}
	
	//deposit amount in wallet
	@Override
	public String deposit(Customer customer, double amount)throws CustomerNotFound {
		
		return CustomerDao.deposit(customer, amount);
	}
	
	
	
	
	
	
	//returns records in list
		@Override
		public List<Transaction> printTransaction(Customer customer) {
			return CustomerDao.printTransaction(customer);
		}

		
		//create user
	@Override
	public Customer createCustomer(Customer customer) throws CustomerExists {
		try {
			return CustomerDao.createCustomer(customer);
		} catch (CustomerExists e) {
			throw new CustomerExists(e.getMessage());
		}
	}
	
	//login method
	@Override
	public Customer checkUser(String username, String password) throws CustomerNotFound {
		try {
			return CustomerDao.checkUser(username, password);
		} catch (CustomerNotFound e) {
			throw new CustomerNotFound(e.getMessage());
		}
	}
	@Override
	public double checkBalance(Customer customer) {
		// TODO Auto-generated method stub
		return CustomerDao.checkBalance(customer);
	}
	//store withdraw result and deposit result in array
	@Override
	public String[] fundTransfer(Customer fromCust, Customer toCust,
			double amount) throws InsufficientBalanceExeption {
		String[] result = new String[2];
		try
		{
			result[0] = CustomerDao.withdraw(fromCust, amount);
			result[1] = CustomerDao.deposit(toCust, amount);
			return result;
		}catch(InsufficientBalanceExeption | CustomerNotFound e)
		{
			throw new InsufficientBalanceExeption(e.getMessage());
		}		
	}

}

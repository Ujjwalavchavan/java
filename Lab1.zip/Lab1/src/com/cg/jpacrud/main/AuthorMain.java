package com.cg.jpacrud.main;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;

import com.cg.jpacrud.entities.Author;
import com.cg.jpacrud.service.AuthorService;
import com.cg.jpacrud.service.AuthorServiceImpl;

public class AuthorMain {
	public static void main(String[] args) {

		// Creating reference of AuthorServiceImpl class
		AuthorService authorService = new AuthorServiceImpl();
		Author author = new Author();

		author.setPhoneNo("9029519704");
		author.setFirstName("Ujjwala");
		author.setMiddleName("vishwas");
		author.setLastName("Chavan");

		// Inserting above set values in database
		authorService.insert(author);

		// Finding Author by Id
		author = authorService.findById(author.getAuthorId());
		System.out.println("ID:" + author.getAuthorId());
		System.out.println("Phone Number:" + author.getPhoneNo());
		System.out.println("FirstName:" + author.getFirstName());
		System.out.println("MiddleName:" + author.getMiddleName());
		System.out.println("LastName:" + author.getLastName());

		// Updating value of MiddleName column
		author.setMiddleName("Neelam");
		authorService.update(author);

		// Printing values of the table after updating
		author = authorService.findById(author.getAuthorId());
		System.out.println("ID:" + author.getAuthorId());
		System.out.println("Phone Number:" + author.getPhoneNo());
		System.out.println("FirstName:" + author.getFirstName());
		System.out.println("MiddleName:" + author.getMiddleName());
		System.out.println("LastName:" + author.getLastName());

		// Delete record from table
		authorService.delete(author);
		System.out.println("Record is deleted");

		System.out.println("End of program...");
	}
}

package com.cg.jpacrud.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Column;

//Annotation states that Author is an entity
@Entity
@Table(name="Author_Table")
public class Author {

	private static final long serialVersionUID = 1L;
	
	//Declaring class members
	@Id //Defining authordId as primary key for table
	@GeneratedValue(strategy=GenerationType.AUTO)
	int authorId;
	String phoneNo;
	String firstName;
	String middleName;
	String lastName;
	
	//Getters and Setters for above declared members
	public int getAuthorId() {
		return authorId;
	}

	public void setAuthorId(int authorId) {
		this.authorId = authorId;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

}

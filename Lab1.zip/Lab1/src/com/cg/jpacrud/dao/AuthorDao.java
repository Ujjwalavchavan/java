package com.cg.jpacrud.dao;

import com.cg.jpacrud.entities.Author;

public interface AuthorDao {
	//Declaring methods to perform CRUD operations

	public abstract void insert(Author author);

	public abstract void update(Author author);

	public abstract void delete(Author author);

	public abstract Author findById(int id);

	public abstract void commitTransaction();

	public abstract void rollBackTransaction();

	public abstract void beginTransaction();

}

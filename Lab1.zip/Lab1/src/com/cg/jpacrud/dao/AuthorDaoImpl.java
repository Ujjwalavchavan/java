package com.cg.jpacrud.dao;

import javax.persistence.EntityManager;

import com.cg.jpacrud.entities.Author;

public class AuthorDaoImpl implements AuthorDao {
	
	private EntityManager entityManager;

	public AuthorDaoImpl() {
		entityManager = JPAUtil.getEntityManager();
	}

	@Override
	public void insert(Author author) {
		entityManager.persist(author);

	}

	@Override
	public void update(Author author) {
		entityManager.merge(author);

	}

	@Override
	public void delete(Author author) {
		entityManager.remove(author);

	}

	@Override
	public Author findById(int id) {
		Author author = entityManager.find(Author.class, id);
		return author;
	}

	@Override
	public void commitTransaction() {
		entityManager.getTransaction().commit();

	}

	@Override
	public void rollBackTransaction() {
		entityManager.getTransaction().rollback();

	}

	@Override
	public void beginTransaction() {
		entityManager.getTransaction().begin();
	}

}

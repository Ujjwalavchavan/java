package com.cg.jpa.test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.jpacrud.entities.Author;

public class TestAuthor {

	private static EntityManager mgr;

	@BeforeClass
	public static void init() {
		EntityManagerFactory factory = Persistence
				.createEntityManagerFactory("LabBook");
		mgr = factory.createEntityManager();
	}

	@Before
	public void start() {
		mgr.getTransaction().begin();
	}

	@After
	public void stop() {
		mgr.getTransaction().commit();
	}

	@Test
	public void testFetch() {
		Author author = (Author) mgr.find(Author.class, 122);
		System.out.println("Author:" + author.getFirstName());
		System.out.println(author.getPhoneNo());
	}

	@Test
	public void testUpdate() {
		Author author = (Author) mgr.find(Author.class, 122);
		author.setLastName("Dabhekar");
	}

	@AfterClass
	public static void flush() {
		mgr.close();
	}

}

//package name
package com.cg.paymentwallet.bean;

public class PaymentWallet {

	// Declaring bean class variables
	private int accNo;
	private String name;
	private long mobile;
	private String email;
	protected double balance;

	// Default constructor
	public PaymentWallet() {
	}

	// Parameterized constructor
	public PaymentWallet(String name, long mobile, String email) {
		this.name = name;
		this.mobile = mobile;
		this.email = email;
	}

	// Getters And Setters for class variables
	public int getAccNo() {
		return accNo;
	}

	public void setAccNo(int accNo) {
		this.accNo = accNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getMobile() {
		return mobile;
	}

	public void setMobile(long mobile) {
		this.mobile = mobile;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	// To String method to display the values
	public String toString() {
		return "Customer Account number = " + accNo + "\nCustomer Name = "
				+ name + "\nCustomer Mobile number= " + mobile
				+ "\nCustomer Email Address = " + email
				+ "\nAvailable Balance = " + balance;
	}
}

//package name
package com.cg.paymentwallet.bean;

public class Transaction {

	// Declaring class variables
	private String type;
	private double amount, balance;

	// Default Constructor
	public Transaction() {
	}

	// Parameterized Constructor
	public Transaction(String type, double amount, double balance) {

		this.type = type;
		this.amount = amount;
		this.balance = balance;
	}

	// To String method for printing the values
	public String print() {
		return (type + "\t" + amount + "\t" + balance);
	}
}

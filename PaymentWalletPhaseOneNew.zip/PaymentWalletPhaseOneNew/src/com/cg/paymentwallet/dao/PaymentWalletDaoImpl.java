//package name
package com.cg.paymentwallet.dao;

import java.util.ArrayList;

import java.util.HashMap;
import java.util.Map;

import com.cg.paymentwallet.bean.PaymentWallet;
import com.cg.paymentwallet.bean.Transaction;
import com.cg.paymentwallet.exception.BalanceException;
import com.cg.paymentwallet.exception.RecordNotFoundException;
import com.cg.paymentwallet.dao.PaymentWalletDaoImpl;

public class PaymentWalletDaoImpl implements PaymentWalletDao {

	// Map for saving the customers
	private Map<Integer, PaymentWallet> customer = new HashMap<Integer, PaymentWallet>();

	// Map for Storing and transaction records
	private Map<Integer, ArrayList<Transaction>> transaction = new HashMap<Integer, ArrayList<Transaction>>();

	// ArrayList for saving the transaction records
	private ArrayList<Transaction> txns = null;
	private static int accountCounter = 7011501;// Account number for first
												// customer entry

	// Method for Creating Account
	@Override
	public void openAccount(PaymentWallet paymentWallet) {
		txns = new ArrayList<Transaction>();
		paymentWallet.setAccNo(accountCounter);
		paymentWallet.setBalance(1000);
		customer.put(accountCounter, paymentWallet);// Putting customer in
													// accounts map with account
													// number
		System.out
				.println("\n*****Customer information saved successfully*****");
		accountCounter++;
	}

	// Method for Showing Account Balance
	@Override
	public double showBalance(int accId) throws RecordNotFoundException {
		PaymentWallet paymentWallet = customer.get(accId);
		if (paymentWallet != null)
			return paymentWallet.getBalance();
		else
			throw new RecordNotFoundException(
					"Accound Record not found.\nPlease Open an Account");
	}

	// Method for Deposit Functionality
	@Override
	public void deposit(int accID, double amount)
			throws RecordNotFoundException {
		PaymentWallet paymentWallet = customer.get(accID);
		if (paymentWallet != null) {
			double amt = paymentWallet.getBalance();
			double newAmount = amt + amount;
			System.out.println("*****Transaction Done Successfully*****");
			System.out.println("Your updated bank balance is " + newAmount);
			paymentWallet.setBalance(newAmount);

			if (txns.size() == 0) {
				txns.add(new Transaction("CR", amount, (amt + amount)));
				transaction.put(paymentWallet.getAccNo(), txns);
			} else {
				txns = transaction.get(accID);

				txns.add(new Transaction("CR", amount, (amt + amount)));
				transaction.remove(paymentWallet.getAccNo());
				transaction.put(paymentWallet.getAccNo(), txns);

			}
		} else
			throw new RecordNotFoundException(
					"Accound Record not found.\nFirst Open Account");
	}

	// Method for Show Transaction Functionality
	@Override
	public void Showtransaction(int userAccId) throws RecordNotFoundException {
		ArrayList<Transaction> trans = transaction.get(userAccId);
		if (trans != null) {
			System.out.println("Type\tAmount\tBalance");
			for (Transaction transaction : trans) {
				System.out.println(transaction.print());
			}
		} else
			throw new RecordNotFoundException(
					"Accound Record not found.\nFirst Open Account");
	}

	// Method for Withdraw Functionality
	@Override
	public void withdraw(int accId, double amount) throws BalanceException,
			RecordNotFoundException {
		PaymentWallet acc = customer.get(accId);
		if (acc != null) {
			double amt = acc.getBalance();

			if (amount <= amt) {
				acc.setBalance(amt - amount);
				System.out.println("*****Transaction Done Successfully*****");
				System.out.println("Your updated bank balance is "
						+ (amt - amount));

				if (txns.size() == 0) {
					txns.add(new Transaction("DR", amount, (amt - amount)));
					transaction.put(acc.getAccNo(), txns);
				} else {
					txns = transaction.get(accId);
					txns.add(new Transaction("DR", amount, (amt - amount)));
					transaction.remove(acc.getAccNo());
					transaction.put(acc.getAccNo(), txns);
				}
			} else
				throw new BalanceException("Insufficient Balance");
		} else
			throw new RecordNotFoundException(
					"Accound Record not found.\nPlease Open an Account");
	}

	// Method for Fund Transfer Functionality
	@Override
	public void fundTransfer(int source, int target, double amount)
			throws BalanceException, RecordNotFoundException {
		withdraw(source, amount);

		PaymentWallet paymentWallet = customer.get(source);
		double debit = paymentWallet.getBalance();
		debit = debit - amount;
		System.out.println("amount at source:" + paymentWallet.getBalance());

		deposit(target, amount);

		PaymentWallet paymentWalletTarget = customer.get(target);
		double credit = paymentWalletTarget.getBalance();
		credit = credit + amount;
		System.out.println("amount at target:"
				+ paymentWalletTarget.getBalance());

		

}
}

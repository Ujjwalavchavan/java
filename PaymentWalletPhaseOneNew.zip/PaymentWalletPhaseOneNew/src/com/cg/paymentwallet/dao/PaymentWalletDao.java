//package name
package com.cg.paymentwallet.dao;

//Required imports
import com.cg.paymentwallet.bean.PaymentWallet;
import com.cg.paymentwallet.exception.BalanceException;
import com.cg.paymentwallet.exception.RecordNotFoundException;

public interface PaymentWalletDao {

	int MINIMUM_BALANCE = 0;

	// Declaring methods for required functionalities
	void openAccount(PaymentWallet paymentWallet);

	double showBalance(int accId) throws RecordNotFoundException;

	void deposit(int accID, double amount) throws RecordNotFoundException;

	void Showtransaction(int userAccId) throws RecordNotFoundException;

	void withdraw(int accId, double amount) throws BalanceException,
			RecordNotFoundException;

	void fundTransfer(int source, int target, double amount)
			throws BalanceException, RecordNotFoundException;
}

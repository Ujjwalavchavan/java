//package name
package com.cg.paymentwallet.service;

import com.cg.paymentwallet.bean.PaymentWallet;
import com.cg.paymentwallet.dao.PaymentWalletDaoImpl;
import com.cg.paymentwallet.exception.BalanceException;
import com.cg.paymentwallet.exception.RecordNotFoundException;

public class PaymentWalletServiceImpl implements PaymentWalletService {

	PaymentWalletDaoImpl paymentWalletDaoImpl = new PaymentWalletDaoImpl();

	// Definition for overridden methods of PaymentWalletService interface
	@Override
	public boolean validateUserName(String userName) {
		if (userName.matches(CUSTOMER_NAME_PATTERN))
			return true;
		else
			return false;
	}

	@Override
	public boolean validateMobile(String mobile) {
		if (mobile.matches(MOBILE_PATTERN))
			return true;
		else
			return false;
	}

	@Override
	public boolean validateEmail(String email) {
		if (email.matches(EMAIL_PATTERN))
			return true;
		else
			return false;
	}

	@Override
	public boolean validateEntry(String ch) {
		if (ch.matches(CHOICE))
			return true;
		else
			return false;
	}

	@Override
	public void openAccount(PaymentWallet acc) {
		paymentWalletDaoImpl.openAccount(acc);

	}

	@Override
	public boolean validateAccId(String userAccId) {
		if (userAccId.matches(ACC_NO))
			return true;
		else
			return false;
	}

	@Override
	public double showBalance(int accId) throws RecordNotFoundException {
		return paymentWalletDaoImpl.showBalance(accId);

	}

	@Override
	public boolean validateAmount(String amount) {
		if (amount.matches(AMOUNT))
			return true;
		else
			return false;
	}

	@Override
	public void deposit(int accId, double amount)
			throws RecordNotFoundException {

		paymentWalletDaoImpl.deposit(accId, amount);

	}

	@Override
	public void Showtransaction(int userAccId) throws RecordNotFoundException {
		paymentWalletDaoImpl.Showtransaction(userAccId);

	}

	@Override
	public void withdraw(int accId, double amount) throws BalanceException,
			RecordNotFoundException {

		paymentWalletDaoImpl.withdraw(accId, amount);

	}

	@Override
	public void fundTransfer(int source, int target, double amount) {
		try {
			paymentWalletDaoImpl.fundTransfer(source, target, amount);
		} catch (BalanceException | RecordNotFoundException e) {
			System.out.println(e.getMessage());
		}

	}
}

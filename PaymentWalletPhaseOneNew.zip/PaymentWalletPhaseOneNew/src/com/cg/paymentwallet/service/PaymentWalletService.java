//package name
package com.cg.paymentwallet.service;

//Required imports
import com.cg.paymentwallet.bean.PaymentWallet;
import com.cg.paymentwallet.exception.BalanceException;
import com.cg.paymentwallet.exception.RecordNotFoundException;
import java.lang.*;

public interface PaymentWalletService {

	// Regular expressions for user inputs 
	String CHOICE = "[1-7]{1}";
	String ACC_NO = "[0-9]{7}";
	String AMOUNT = "[0-9]{1,10}";
	String CUSTOMER_NAME_PATTERN = "[a-zA-z]{1,20}";
	String ADDRESS_PATTERN = "[A-Za-z]{1,25}";
	String MOBILE_PATTERN = "[1-9]{1}[0-9]{9}";
	String EMAIL_PATTERN = "[a-zA-z0-9]{1,12}[@][a-zA-Z]{4,10}[.][a-zA-Z]{3}";

	// Declaring methods for validating user input
	boolean validateUserName(String userName);

	boolean validateMobile(String mobile);

	boolean validateEmail(String email);

	boolean validateEntry(String ch);

	boolean validateAccId(String userAccId);

	boolean validateAmount(String amount);

	void openAccount(PaymentWallet paymentWallet);

	double showBalance(int accId) throws RecordNotFoundException;

	void deposit(int accId, double amount) throws RecordNotFoundException;

	void Showtransaction(int userAccId) throws RecordNotFoundException;

	void withdraw(int accId, double amount) throws BalanceException,
			RecordNotFoundException;

	void fundTransfer(int source, int target, double amount);
}

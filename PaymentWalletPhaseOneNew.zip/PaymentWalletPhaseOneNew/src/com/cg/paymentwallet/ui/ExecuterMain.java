//package name
package com.cg.paymentwallet.ui;

//Importing files from required packages
import java.util.Scanner;
import com.cg.paymentwallet.bean.PaymentWallet;
import com.cg.paymentwallet.service.PaymentWalletServiceImpl;
import com.cg.paymentwallet.exception.BalanceException;
import com.cg.paymentwallet.exception.RecordNotFoundException;

public class ExecuterMain {

	@SuppressWarnings("resource")
	public static void main(String[] args) {

		// Declaring Data Members
		String choice;
		String customerName;
		String customerEmail;
		String customerMobile;
		String customerAccId;
		String amount;
		String sourceAccId;
		String targetAccId;
		Scanner scanner;
		boolean isValid;

		// Service class object
		PaymentWalletServiceImpl paymentWalletServiceImpl = new PaymentWalletServiceImpl();
		scanner = new Scanner(System.in);

		System.out
				.println("\n!!!!!--------Welcome To Kotak Mahindra-------!!!!!\n");

		// while loop for entire application
		while (true) {

			// while loop for menu of application
			while (true) {

				System.out
						.println("\n\t\t1.Create Account\n\t\t2.Show Balance\n\t\t3.Deposit\n\t\t4.Withdraw"
								+ "\n\t\t5.Fund Transfer\n\t\t6.Show Transaction\n\t\t7.Exit\n");
				choice = scanner.next();

				isValid = paymentWalletServiceImpl.validateEntry(choice);// validating
																			// choices
																			// made
																			// by
																			// user
				if (isValid)
					break; // breaks when input is valid
				else
					System.out.println("Please enter Valid Choice from 1 to 6");
			}

			// Respected cases according to user choices
			switch (choice) {
			// For obtaining customer details and creating account
			case "1":

				while (true) {
					// For customer name
					System.out.println("Enter your name:");
					customerName = scanner.next();

					// To validate customer name
					isValid = paymentWalletServiceImpl
							.validateUserName(customerName);
					if (isValid)
						break; // breaks when input is valid
					else
						System.out
								.println("Please enter valid naming format.\nName should have minimum 1 or max 10 characters");
				}

				while (true) {
					// For customer email address
					System.out.println("Enter your email address:");
					customerEmail = scanner.next();

					// To validate customer email address
					isValid = paymentWalletServiceImpl
							.validateEmail(customerEmail);
					if (isValid)
						break;// breaks when input is valid
					else
						System.out
								.println("Please enter valid email address format for example ujjwala04@gmail.com");
				}
				while (true) {
					// For customer mobile number
					System.out.println("Enter your mobile number:");
					customerMobile = scanner.next();

					// To validate customer mobile number
					isValid = paymentWalletServiceImpl
							.validateMobile(customerMobile);
					if (isValid)
						break;// breaks when input is valid
					else
						System.out
								.println("Please enter Valid Mobile without +91 for example 9029519704");
				}
				// Passing value to the constructor of bean class
				PaymentWallet paymentWallet = new PaymentWallet(customerName,
						Long.parseLong(customerMobile), customerEmail);

				// Passing bean class object to service class openAccount Method
				// and storing data in map
				paymentWalletServiceImpl.openAccount(paymentWallet);

				// Printing Customer details
				System.out.println(paymentWallet);
				break;// Case 1 breaks

			// To display the available account balance
			case "2":
				while (true) {
					System.out.println("Enter your account number:");
					customerAccId = scanner.next();

					// Validating customer account number
					isValid = paymentWalletServiceImpl
							.validateAccId(customerAccId);
					if (isValid)
						break; // breaks when input is valid
					else
						System.out.println("Please enter valid account number");
				}
				try {
					System.out.println("Your Account Balance is "
							+ paymentWalletServiceImpl.showBalance(Integer
									.parseInt(customerAccId)));
				} catch (RecordNotFoundException e) {
					System.out.println(e);
				}
				break;// Case 2 breaks

			// For Deposit Functionality
			case "3":
				// Validating account number
				while (true) {
					System.out.println("Enter your account number:");
					customerAccId = scanner.next();

					isValid = paymentWalletServiceImpl
							.validateAccId(customerAccId);
					if (isValid)
						break; // breaks when input is valid
					else
						System.out
								.println("Please enter valid account number ");
				}
				// Validating amount entered by user
				while (true) {
					System.out.println("Enter the amount for deposit:");
					amount = scanner.next();
					isValid = paymentWalletServiceImpl.validateAmount(amount);
					if (isValid)
						break; // breaks when input is valid
					else
						System.out
								.println("Please enter vaid amount value eg.1000");
				}
				try {
					paymentWalletServiceImpl.deposit(
							Integer.parseInt(customerAccId),
							Double.parseDouble(amount));

				} catch (RecordNotFoundException e) {
					System.out.println(e);
				}

				break;// Case 3 breaks

			// For Withdraw Functionality
			case "4":
				// Validating customer account number
				while (true) {
					System.out.println("Enter your account number:");
					customerAccId = scanner.next();
					isValid = paymentWalletServiceImpl
							.validateAccId(customerAccId);
					if (isValid)
						break; // breaks when input is valid
					else
						System.out
								.println("Please enter valid account number ");
				}
				// Validating amount entered by user
				while (true) {
					System.out.println("Enter amount to withdraw:");
					amount = scanner.next();
					isValid = paymentWalletServiceImpl.validateAmount(amount);
					if (isValid)
						break; // breaks when input is valid
					else
						System.out
								.println("Please enter valid amount value eg.1000");
				}
				try {
					paymentWalletServiceImpl.withdraw(
							Integer.parseInt(customerAccId),
							Double.parseDouble(amount));

				} catch (BalanceException | RecordNotFoundException e) {
					System.out.println(e);
				}
				break;// Case 4 breaks

			// For Fund Transfer Functionality
			case "5":
				// Validating customer account number
				while (true) {
					System.out.println("Enter your account number");
					sourceAccId = scanner.next();
					isValid = paymentWalletServiceImpl
							.validateAccId(sourceAccId);
					if (isValid)
						break; // breaks when input is valid
					else
						System.out.println("Please enter Valid Account Id ");
				}
				// Validating Receivers account number
				while (true) {
					System.out.println("Enter receipent account number");
					targetAccId = scanner.next();
					isValid = paymentWalletServiceImpl
							.validateAccId(targetAccId);
					if (isValid)
						break; // breaks when input is valid
					else
						System.out.println("Please enter Valid Account Id ");
				}
				// Validating the transfer amount
				while (true) {
					System.out.println("Enter Fund transfer amount");
					amount = scanner.next();
					isValid = paymentWalletServiceImpl.validateAmount(amount);
					if (isValid)
						break; // breaks when input is valid
					else
						System.out.println("Please enter valid amount eg.1000");
				}
				paymentWalletServiceImpl.fundTransfer(
						Integer.parseInt(sourceAccId),
						Integer.parseInt(targetAccId),
						Double.parseDouble(amount));
				System.out.println("*****Transaction Done Successfully*****");
				break;// Case 5 breaks

			// For Displaying Transaction
			case "6":
				// Validating customer account number
				while (true) {
					System.out.println("Enter your account number:");
					customerAccId = scanner.next();
					isValid = paymentWalletServiceImpl
							.validateAccId(customerAccId);
					if (isValid)
						break; // breaks when input is valid
					else
						System.out
								.println("Please enter valid account number:");
				}
				try {
					paymentWalletServiceImpl.Showtransaction(Integer
							.parseInt(customerAccId));
				} catch (NumberFormatException | RecordNotFoundException e) {
					System.out.println(e);
				}
				break;// Case 6 breaks

			// Application Exit
			case "7":
				System.out.println("---------Thank You--------");
				System.out.println("!!!!!!  Visit Again  !!!!!");
				System.exit(0);

				break;
			default:
				break;
			}
		}
	}
}

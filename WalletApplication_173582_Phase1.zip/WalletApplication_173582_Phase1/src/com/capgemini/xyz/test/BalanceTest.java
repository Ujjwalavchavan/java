package com.capgemini.xyz.test;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.dao.CustomerDao;
import com.capgemini.xyz.exception.InsufficientBalanceException;


public class BalanceTest {

	CustomerDao cdao = null;
	
	@Before
	public void setUp() throws Exception {

		cdao = new CustomerDao();
	}

	@After
	public void tearDown() throws Exception {
		cdao = null;
	}
	
	//Test cases for withdraw
	@Test
	public void testWithdrawValidDetails() {
		Customer c=new Customer("Laxmi", "9167968584", "laxmi@gmail.com","1000");
		cdao.storeCustomerDetails(c);
		try{
		double amt = Double.parseDouble(c.getBalance());
		cdao.withdraw(c, "400");
		double upadatedAmount = Double.parseDouble(c.getBalance());
		amt-=upadatedAmount;
		Assert.assertTrue(amt==upadatedAmount);
		}catch(InsufficientBalanceException e){
			System.out.println(e);
		}
	}
	
	@Test
	public void testWithdrawInvalidDetails() throws InsufficientBalanceException{
		Customer acc=new Customer("Laxmi", "9167968584", "laxmi@gmail.com","1000");
		cdao.storeCustomerDetails(acc);
		try{
		String amount = acc.getBalance();
		cdao.withdraw(acc, "4000");
		double amt = Double.parseDouble(amount);
		Assert.assertFalse(amt==amt-2000);
		}catch(InsufficientBalanceException e){
			System.out.println(e);
		}
	}
	
	//Test cases for fund transfer
	@Test
	public void testFundTransferDetails() {
		Customer c=new Customer("Laxmi", "9167968584", "laxmi@gmail.com","1000");
		cdao.storeCustomerDetails(c);
		try{
		double amt = Double.parseDouble(c.getBalance());
		cdao.fundTransfer(c,"1234567890", "400");
		double upadatedAmount = Double.parseDouble(c.getBalance());
		amt-=upadatedAmount;
		Assert.assertTrue(amt==upadatedAmount);
		}catch(InsufficientBalanceException e){
			System.out.println(e);
		}
	}
	
	@Test
	public void testFundTransferDetailsInvalid(){
		Customer acc=new Customer("Laxmi", "9167968584", "laxmi@gmail.com","1000");
		cdao.storeCustomerDetails(acc);
		try{
		String amount = acc.getBalance();
		cdao.fundTransfer(acc, "1234567890","4000");
		double amt = Double.parseDouble(amount);
		Assert.assertFalse(amt==amt-2000);
		}catch(InsufficientBalanceException e){
			System.out.println(e);
		}
	}
}

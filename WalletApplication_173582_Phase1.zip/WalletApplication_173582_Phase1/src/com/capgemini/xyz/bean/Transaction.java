package com.capgemini.xyz.bean;

public class Transaction {
	
	//declaring constants 
	public String type;
	private String amount,balance;
	
	//constructores
	public Transaction(){
		
	}
	
	public Transaction(String type,String amount, String balance) {
		this.type = type;
		this.amount = amount;
		this.balance = balance;
	}

	//to print all transaction
	public String print(){
		return (type+"\t"+amount+"\t"+balance);
	}
}

package com.capgemini.xyz.service;

//importing packages
import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.dao.CustomerDao;
import com.capgemini.xyz.exception.InsufficientBalanceException;


public class ServiceClass implements ServiceInterface {
	
	CustomerDao cd = new CustomerDao();

	//overriding method to validate name
	@Override
	public boolean validName(String name) {
		boolean isValid = false;
		if(name.matches(NAMEPATTERN))
			isValid = true;
		
		return isValid;
	}

	//overriding method to validate mobile number
	@Override
	public boolean validNumber(String number) {
		boolean isValid = false;
		if(number.matches(NUMBERPATTERN))
			isValid = true;
		
		return isValid;
	}

	
	//overriding method to validate email
	@Override
	public boolean validEmail(String email) {
		boolean isValid = false;
		if(email.matches(EMAILPATTERN))
			isValid = true;
		
		return isValid;
	}

	
	//overriding method to validate email
	@Override
	public boolean validAmount(String amount) {
		boolean isValid = false;
		if(amount.matches(AMOUNTPATTERN))
			isValid = true;
		
		return isValid;
	}

	//overriding method to validate account number
	@Override
	public boolean validAccount(String account) {
		boolean isValid = false;
		if(account.matches(AMOUNTPATTERN))
			isValid = true;
		
		return isValid;
	}
	
	//overriding method to store details in hashmap
	@Override
	public void storeCustomerDetails(Customer c) {
		cd.storeCustomerDetails(c);
	}

	//invoke method of CustomerDao to show balance
	public String showBalance(long custId,Customer c) {
		return  cd.showBalance(custId,c);
		
	}

//	invoke method of CustomerDao to deposite
	public void deposite(Customer c, String amount) {
		cd.deposite(c, amount);
	}

//	invoke method of CustomerDao to withdraw
	public void withdraw(Customer c, String withdrawAmount) throws InsufficientBalanceException {
		cd.withdraw(c, withdrawAmount);
	}
	
//	invoke method of CustomerDao to transfer money to another account
	public void fundTransfer(Customer c, String accNumber, String amount) throws InsufficientBalanceException {
		cd.fundTransfer(c, accNumber, amount);
	}
	
	public void printTransaction(){
		cd.printTransaction();
	}
}

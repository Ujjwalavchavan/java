package com.cg.step;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PersonalStepDefinition {
	@Given("^User is on personal details page$")
	public void user_is_on_personal_details_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Validate personal details page$")
	public void validate_personal_details_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user enters first name$")
	public void user_enters_first_name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Validate first name$")
	public void validate_first_name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User enters last name$")
	public void user_enters_last_name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Validate last name$")
	public void validate_last_name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user enter email address$")
	public void user_enter_email_address() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^validate email address$")
	public void validate_email_address() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User enters contact number$")
	public void user_enters_contact_number() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Validate contact number$")
	public void validate_contact_number() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user enter address (\\d+)$")
	public void user_enter_address(int arg1) throws Throwable {
	    
	}

	@Then("^validate address (\\d+)$")
	public void validate_address(int arg1) throws Throwable {
	    
	}

	@When("^user selects city$")
	public void user_selects_city() throws Throwable {
	    
	}

	@Then("^validate city$")
	public void validate_city() throws Throwable {
	    
	}

	@When("^User selects state$")
	public void user_selects_state() throws Throwable {
	    
	}

	@Then("^Validate state$")
	public void validate_state() throws Throwable {
	   
	}

	@When("^User clicks on next link$")
	public void user_clicks_on_next_link() throws Throwable {
	    
	}

	@Then("^Redirect to Educational Details Page$")
	public void redirect_to_Educational_Details_Page() throws Throwable {
	   
	}


}

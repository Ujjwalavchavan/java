package com.cg.step;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.bean.PersonalBean;

import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PersonalStepDefinition {
	
	
	private WebDriver driver;
	private PersonalBean personalBeans;
	
	@cucumber.api.java.Before
	public void setUpStepEnvironment() {
		System.setProperty("webdriver.chrome.driver","mydriver\\chromedriver.exe");
	}
	
	

	@Given("^User is on Personal Details Page$")
	public void user_is_on_PersonalDetails_Page() throws Throwable {
		driver = new ChromeDriver();
		String url ="C:\\Users\\ujchavan\\Desktop\\ujjwala\\Module3\\Bdd\\PersonalDetails\\html/PersonalDetails.html";
		driver.get(url);
		personalBeans = new PersonalBean();
		PageFactory.initElements(driver, personalBeans);Thread.sleep(4000);   
	}

	@When("^user enters valid details$")
	public void user_enters_valid_details() throws Throwable {
		personalBeans.setFirstName("ujjwala");
		personalBeans.setLastName("chavan");
		personalBeans.setEmail("ujjwalachavan04@gmail.com");
		personalBeans.setPhoneNumber("9029519704");
		personalBeans.setAddress("Plot no.5");
		personalBeans.setArea("Cidco colony");
		personalBeans.clickCity();
		personalBeans.clickNextButton();Thread.sleep(4000);
	   
	}

	@Then("^display Personal details are validated$")
	public void display_Personal_details_are_validated() throws Throwable {
		String expectedMessage="Personal details are validated.";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();Thread.sleep(4000);
	}
	
	@When("^user enters url$")
	public void user_enters_url() throws Throwable {
	    
	}

	@Then("^page should be loaded$")
	public void page_should_be_loaded() throws Throwable {
		String expectedPageTitle="Personal Details";
		String actualPageTitle=driver.getTitle();
		Assert.assertEquals(expectedPageTitle, actualPageTitle);
		driver.close();Thread.sleep(4000);
	}
	
	@When("^user enters invalid firstName$")
	public void user_enters_invalid_firstName() throws Throwable {
		personalBeans.setFirstName("");
		personalBeans.clickNextButton();Thread.sleep(3000);
	}

	@Then("^display Please fill the First Name$")
	public void display_Please_fill_the_First_Name() throws Throwable {
		String expectedMessage="Please fill the First Name";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();Thread.sleep(4000);
	}

	@When("^user enters invalid lastName$")
	public void user_enters_invalid_lastName() throws Throwable {
		personalBeans.setFirstName("ujjwala");
		personalBeans.setLastName("");
		personalBeans.clickNextButton();Thread.sleep(4000);
	}

	@Then("^display Please fill the Last Name$")
	public void display_Please_fill_the_Last_Name() throws Throwable {
		String expectedMessage="Please fill the Last Name";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();Thread.sleep(4000);
	}
	
	@When("^user does not enter  email$")
	public void user_does_not_enter_email() throws Throwable {
		personalBeans.setFirstName("ujjwala");
		personalBeans.setLastName("chavan");
		personalBeans.clickNextButton();Thread.sleep(4000);
	}

	@Then("^display Please fill the Email id $")
	public void display_Please_fill_the_Email_id() throws Throwable {
		String expectedMessage="Please fill the Email";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().dismiss();
		driver.close();Thread.sleep(4000);
	}


	@When("^user enters invalid email$")
	public void user_enters_invalid_email() throws Throwable {
		personalBeans.setFirstName("ujjwala");
		personalBeans.setLastName("chavan");
		personalBeans.setEmail("ujjwalachavan04gmail.com");
		personalBeans.clickNextButton();Thread.sleep(4000);
	}

	@Then("^display Please fill the Email$")
	public void display_Please_fill_the_Email() throws Throwable {
		String expectedMessage="Please enter valid Email Id.";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();Thread.sleep(4000); 
	}
	

	@When("^user does not enter contact number$")
	public void user_does_not_enter_contact_number() throws Throwable {
		personalBeans.setFirstName("ujjwala");
		personalBeans.setLastName("chavan");
		personalBeans.setEmail("ujjwalachavan04@gmail.com");
		personalBeans.clickNextButton();Thread.sleep(3000);
	}

	@Then("^display Please fill valid Contact number\\.$")
	public void display_Please_fill_valid_Contact_number() throws Throwable {
		String expectedMessage="Please fill the Contact No.";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().dismiss();
		driver.close();Thread.sleep(4000);
	}

	@When("^user enters invalid contact number$")
	public void user_enters_invalid_contact_number() throws Throwable {
		personalBeans.setFirstName("ujjwala");
		personalBeans.setLastName("chavan");
		personalBeans.setEmail("ujjwalachavan04@gmail.com");
		personalBeans.setPhoneNumber("90295");
		personalBeans.clickNextButton();Thread.sleep(3000);
	}

	@Then("^display Please fill valid Contact no\\.$")
	public void display_Please_fill_valid_Contact_no() throws Throwable {
		String expectedMessage="Please enter valid Contact no.";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().dismiss();
		driver.close();Thread.sleep(3000);
	}

	@When("^user enters invalid Building name and room no$")
	public void user_enters_invalid_Building_name_and_room_no() throws Throwable {
		personalBeans.setFirstName("ujjwala");
		personalBeans.setLastName("chavan");
		personalBeans.setEmail("ujjwalachavan04@gmail.com");
		personalBeans.setPhoneNumber("9029519704");
		personalBeans.setAddress("");
		personalBeans.clickNextButton();Thread.sleep(3000);
	}

	@Then("^display Please fill Building name and room no$")
	public void display_Please_fill_Building_name_and_room_no() throws Throwable {
		String expectedMessage="Please fill the Building & Room No";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();Thread.sleep(4000);
	}

	@When("^user enters invalid Area name$")
	public void user_enters_invalid_Area_name() throws Throwable {
		personalBeans.setFirstName("ujjwala");
		personalBeans.setLastName("chavan");
		personalBeans.setEmail("ujjwalachavan04@gmail.com");
		personalBeans.setPhoneNumber("9029519704");
		personalBeans.setAddress("Plot no.5");
		personalBeans.setArea("");
		personalBeans.clickNextButton();Thread.sleep(4000);
	}

	@Then("^display Please fill Area name$")
	public void display_Please_fill_Area_name() throws Throwable {
		String expectedMessage="Please fill the Building & Room No";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();Thread.sleep(4000);
	}

	@When("^user enters invalid City$")
	public void user_enters_invalid_City() throws Throwable {
		personalBeans.setFirstName("ujjwala");
		personalBeans.setLastName("chavan");
		personalBeans.setEmail("ujjwalachavan04@gmail.com");
		personalBeans.setPhoneNumber("9029519704");
		personalBeans.setAddress("Plot no.5");
		personalBeans.setArea("Cidco colony");
		personalBeans.clickNextButton();Thread.sleep(4000);
	}

	@Then("^display Please fill City$")
	public void display_Please_fill_City() throws Throwable {
		String expectedMessage="Please select city";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();Thread.sleep(4000);
	}

	@When("^user enters invalid State$")
	public void user_enters_invalid_State() throws Throwable {
		personalBeans.setFirstName("ujjwala");
		personalBeans.setLastName("chavan");
		personalBeans.setEmail("ujjwalachavan04@gmail.com");
		personalBeans.setPhoneNumber("9029519704");
		personalBeans.setAddress("Plot no.5");
		personalBeans.setArea("Cidco colony");
		personalBeans.clickCity();
		personalBeans.clickNextButton();Thread.sleep(4000);
	}

	@Then("^display Please fill the State$")
	public void display_Please_fill_the_State() throws Throwable {
		String expectedMessage="Please select state";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();  Thread.sleep(4000);
	}
	@After
	public void destroy() {
		driver.quit();
	}
}

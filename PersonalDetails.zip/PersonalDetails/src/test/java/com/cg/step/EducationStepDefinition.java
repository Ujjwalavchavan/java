package com.cg.step;

import org.junit.Assert;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.bean.EducationBean;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class EducationStepDefinition {
	
	private WebDriver driver;
	EducationBean educationbean;
	

	@Before
	public void setUpStepEnv() {
		System.setProperty("webdriver.chrome.driver", "mydriver\\chromedriver.exe");
	}
	

	
	@Given("^User is on Education Details Page$")
	public void user_is_on_Education_Details_Page() throws Throwable {
		driver = new ChromeDriver();
		String url = "C:\\Users\\ujchavan\\Desktop\\ujjwala\\Module3\\Bdd\\PersonalDetails\\html/EducationalDetails.html";
		driver.get(url);
		educationbean = new EducationBean();
		PageFactory.initElements(driver, educationbean);
	}

	@When("^user selects invalid graduation$")
	public void user_selects_invalid_graduation() throws Throwable {
	
		educationbean.clickLogin();
		Thread.sleep(3000);
	}

	@Then("^display Please Select Graduation$")
	public void display_Please_Select_Graduation() throws Throwable {
		String expectedMessage="Please select graduation";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();Thread.sleep(3000);
	}

	@When("^user enters invalid Percentage$")
	public void user_enters_invalid_Percentage() throws Throwable {
		educationbean.clickGraduation();
		educationbean.clickLogin();
		Thread.sleep(3000);
	}

	@Then("^display Please enter correct Percentage$")
	public void display_Please_enter_correct_Percentage() throws Throwable {
		String expectedMessage="Please select graduation";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();Thread.sleep(3000);
	}

	@When("^user enters invalid Passing year$")
	public void user_enters_invalid_Passing_year() throws Throwable {
		educationbean.clickGraduation();
		educationbean.setPercentage("80");
		educationbean.clickLogin();
		Thread.sleep(3000);
	}

	@Then("^display Please enter valid Passing year$")
	public void display_Please_enter_valid_Passing_year() throws Throwable {
		String expectedMessage="Please select graduation";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();Thread.sleep(3000);
	}

	@When("^user enters invalid project name$")
	public void user_enters_invalid_project_name() throws Throwable {
		educationbean.clickGraduation();
		educationbean.setPercentage("80");
		educationbean.setPassingyear("2017");
		educationbean.clickLogin();
		Thread.sleep(3000);
	}

	@Then("^display Please enter valid Project name\\.$")
	public void display_Please_enter_valid_Project_name() throws Throwable {
		String expectedMessage="Please select graduation";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();Thread.sleep(3000);
	}

	@When("^user enters invalid Technologies$")
	public void user_enters_invalid_Technologies() throws Throwable {
		educationbean.clickGraduation();
		educationbean.setPercentage("80");
		educationbean.setPassingyear("2017");
		educationbean.setProject("BDD");
		educationbean.clickLogin();
		Thread.sleep(3000);
	}

	@Then("^display Please enter valid Technologies$")
	public void display_Please_enter_valid_Technologies() throws Throwable {
		String expectedMessage="Please select graduation";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();Thread.sleep(3000);
	}

	@When("^user enters invalid other Technologies$")
	public void user_enters_invalid_other_Technologies() throws Throwable {
		educationbean.clickGraduation();
		educationbean.setPercentage("80");
		educationbean.setPassingyear("2017");
		educationbean.setProject("BDD");
		educationbean.clickTechnologies();
		educationbean.clickLogin();
		Thread.sleep(3000);
	}

	@Then("^display Please enter valid other Technologies$")
	public void display_Please_enter_valid_other_Technologies() throws Throwable {
		String expectedMessage="Please select graduation";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();Thread.sleep(3000);
	}
	
	

	@When("^user enters valid  payment details$")
	public void user_enters_valid_payment_details() throws Throwable {
		educationbean.clickGraduation();
		educationbean.setPercentage("80");
		educationbean.setPassingyear("2017");
		educationbean.setProject("BDD");
		educationbean.clickTechnologies();
		educationbean.setOtherTechnologies("AI");
		educationbean.clickLogin();
		Thread.sleep(3000);
	}

	@Then("^displays payment successfully done!!!$")
	public void displays_payment_successfully_done() throws Throwable {
		String expectedMessage="Education details are validated.";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();Thread.sleep(3000);
	}

	@After
	public void destroy() {
		driver.quit();
	}

}

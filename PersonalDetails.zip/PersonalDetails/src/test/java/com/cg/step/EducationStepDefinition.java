package com.cg.step;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class EducationStepDefinition {
	@Given("^User is on educational details page$")
	public void user_is_on_educational_details_page() throws Throwable {
	   
	  
	}

	@Then("^Validate educational details page$")
	public void validate_educational_details_page() throws Throwable {
	   
	    
	}

	@When("^user selects graduation details$")
	public void user_selects_graduation_details() throws Throwable {
	    
	    
	}

	@Then("^validate graduation details$")
	public void validate_graduation_details() throws Throwable {
	    	   
	}

	@When("^User enters percentage$")
	public void user_enters_percentage() throws Throwable {
	       
	}

	@Then("^validate percentage$")
	public void validate_percentage() throws Throwable {
	    
	    
	}

	@When("^User enters passing year$")
	public void user_enters_passing_year() throws Throwable {
	    
	   
	}

	@Then("^validate passing year$")
	public void validate_passing_year() throws Throwable {
	    
	    
	}

	@When("^User enters project name$")
	public void user_enters_project_name() throws Throwable {
	   
	    
	}

	@Then("^validate project name$")
	public void validate_project_name() throws Throwable {
	   
	    
	}

	@When("^User enters Technologies$")
	public void user_enters_Technologies() throws Throwable {
	    
	}

	@Then("^validate Technologies$")
	public void validate_Technologies() throws Throwable {
	    
	}

	@When("^User enters Other Technologies$")
	public void user_enters_Other_Technologies() throws Throwable {
	    
	}

	@Then("^validate Other Technologies$")
	public void validate_Other_Technologies() throws Throwable {
	   
	}

	@When("^user submits form$")
	public void user_submits_form() throws Throwable {
	    
	}

	@Then("^show successful alert$")
	public void show_successful_alert() throws Throwable {
	   
	}

}

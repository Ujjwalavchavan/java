package com.cg.test;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
			features = { "src/test/resources" }, 
			//features = { "src/test/resources/personal.feature" },
			//features = {"src/test/resources/education.feature","src/test/resources/personal.feature"},
			glue = { "com.cg.step" },
			tags = {"@Second"})
public class TestRunner {

}
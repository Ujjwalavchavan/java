package com.cg.bean;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class PersonalBean {

	@FindBy(id="txtFirstName")
	WebElement firstName;
	
	@FindBy(id="txtLastName")
	WebElement lastName;
	
	@FindBy(id="txtEmail")
	WebElement email;
	
	@FindBy(id="txtPhone")
	WebElement phoneNumber;
	
	@FindBy(id="txtAddress1")
	WebElement address;
	
	@FindBy(id="txtAddress2")
	WebElement area;
	
	@FindBy(name="city")
	WebElement city;

	@FindBy(name="state")
	WebElement state;
	
	@FindBy(tagName="a")
	WebElement nextButton;
	
//	public Registration() {}
	

	public WebElement getFirstName() {
		return firstName;
	}

	public void setFirstName(WebElement firstName) {
		this.firstName = firstName;
	}

	public WebElement getLastName() {
		return lastName;
	}

	public void setLastName(WebElement lastName) {
		this.lastName = lastName;
	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(WebElement email) {
		this.email = email;
	}

	public WebElement getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(WebElement phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public WebElement getAddress() {
		return address;
	}

	public void setAddress(WebElement address) {
		this.address = address;
	}

	public WebElement getArea() {
		return area;
	}

	public void setArea(WebElement area) {
		this.area = area;
	}
	
	public void clickCity() {
		Select select = new Select(city);
		select.selectByVisibleText("Pune");
	}

	public void clickState() {
		Select select = new Select(state);
		select.selectByVisibleText("Maharashtra");
	}

	public void clickNextButton() {
		nextButton.click();
	}
}

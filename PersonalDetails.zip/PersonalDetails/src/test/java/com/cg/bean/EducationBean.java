package com.cg.bean;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class EducationBean {

	@FindBy(name="graduation")
	WebElement graduation;	
	
//	@FindBy(name="registerme")
//	WebElement registerme;
	
	@FindBy(name="percentage")
	WebElement percentage;
	
	@FindBy(name="passingyear")
	WebElement passingyear;
	
	@FindBy(name="project")
	WebElement project;
	
	@FindBy(name="technologies")
	WebElement technologies;
	
	@FindBy(name="other")
	WebElement other;
	
	@FindBy(name="payment")
	WebElement payment;
	
	public void clickGraduation() {
		Select select = new Select(graduation);
		select.selectByVisibleText("IT");
	}
	
	public void clickTechnologies() {
		Select select = new Select(technologies);
		select.selectByVisibleText("java");
	}
	

	public WebElement getPercentage() {
		return percentage;
	}

	public void setPercentage(WebElement percentage) {
		this.percentage = percentage;
	}

	public WebElement getPassingyear() {
		return passingyear;
	}

	public void setPassingyear(WebElement passingyear) {
		this.passingyear = passingyear;
	}

	public WebElement getProject() {
		return project;
	}

	public void setProject(WebElement project) {
		this.project = project;
	}

	public WebElement getTechnologies() {
		return technologies;
	}

	public void setTechnologies(WebElement technologies) {
		this.technologies = technologies;
	}

	public WebElement getOther() {
		return other;
	}

	public void setOther(WebElement other) {
		this.other = other;
	}
	
	public void clickLogin() {
		payment.click();
	}
}

package com.cg.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.Product;
import com.cg.repo.ProductRepo;

@RestController
public class HelloController {
	@Autowired
	private ProductRepo repo;

	@GetMapping("/hola")
	public String sayHello() {
		return "Welcome to spring boot";

	}
	
	@PostMapping("/add")
	public String saveProduct(@RequestParam("name")String name,@RequestParam("price")double  price)
	{
		Product p =new Product();
	
		p.setName(name);
		p.setPrice(price);
		repo.saveProduct(p);
		return "product saved";
		
	}
	
	@GetMapping(name="/product",produces="application/json")
	public Product getProduct(@RequestParam("id")int id) {
		Product p=repo.get(id);
		return p;
	}

//	@GetMapping("/bye")
//	public String sayGoodBye(@RequestParam("name") String name) {
//		return "Bye" + name + ",Vist again!";
//	}
}

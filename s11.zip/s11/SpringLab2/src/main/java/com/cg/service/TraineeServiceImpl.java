package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.repo.TraineeDao;
import com.cg.entity.Trainee;

@Repository
@Transactional
public class TraineeServiceImpl implements TraineeServiceInterface {

	@Autowired
	TraineeDao traineeDao;
	
	public void saveTrainee(Trainee trainee) {
		traineeDao.save(trainee);
	}

	public Trainee getTrainee(int id) {
		return traineeDao.findById(id).get();
	}

	public Iterable<Trainee> getAll() {
		return traineeDao.findAll();
	}

	public String deleteTrainee(Trainee trainee) {
		traineeDao.delete(trainee);
		return "Delete Successfully";
	}

	public Trainee updateTrainee(Trainee trainee, int id) {
		trainee.setTraineeId(id);
		traineeDao.save(trainee);
		return trainee;
	}	
}

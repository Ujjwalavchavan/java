package com.cg.rest;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.entity.Login;
import com.cg.entity.Trainee;
import com.cg.service.TraineeServiceImpl;

@Controller
public class TraineeController {

	@Autowired
	TraineeServiceImpl traineeService;

	Trainee trainee;

	@RequestMapping("/")
	public String login(Model model) {
		model.addAttribute("login", new Login());
		return "login";
	}

	@RequestMapping(value = "/checkLogin")
	public String checkLogin(Login login) {

		if (login.getUserName().equalsIgnoreCase("polo") && login.getPassword().equalsIgnoreCase("888888"))
			return "loginSuccessfull";
		else {
			return "login";
		}
	}

	@RequestMapping(value = "/add")
	public String addTrainee(Model model) {
		model.addAttribute("addTrainee", new Trainee());
		return "addTrainee";
	}

	@RequestMapping("/addTrainee")
	public String addTrainee(@ModelAttribute("") Trainee addnew, Model model) {
		traineeService.saveTrainee(addnew);
		return "loginSuccessfull";
	}

	@RequestMapping(value = "/delete")
	public String deletepage(Model model) {
		return "Record deleted";
	}

	@RequestMapping("/search")
	public String retrieveTodelete(Model model, @RequestParam("traineeId") int traineeId,  
			HttpServletResponse response) throws ServletException, IOException {
		trainee = traineeService.getTrainee(traineeId);
		model.addAttribute(trainee);
		response.sendRedirect("/my-error-page");
		return "Record deleted";
	}

	@RequestMapping("/deleteTrainee")
	public String deleteTrainee(Model model, Trainee trainee) {
		traineeService.deleteTrainee(trainee);
		return "loginSuccessfull";
	}

	@RequestMapping(value = "/retrieve")
	public String retrieveDetails(Model model) {
		return "retrieve successfull";
	}

	@RequestMapping("/retieveOne")
	public String retrieveSingle(Model model, @RequestParam("traineeId") int traineeId) {
		trainee = traineeService.getTrainee(traineeId);
		model.addAttribute(trainee);
		return "retrieve successfull";
	}

	@RequestMapping("/menu")
	public String retrieveTrainee(Model model, Trainee trainee) {
		traineeService.deleteTrainee(trainee);
		return "loginSuccessfull";
	}
}

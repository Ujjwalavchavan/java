package com.cg.repo;

import org.springframework.data.repository.CrudRepository;

import com.cg.entity.Trainee;

public interface TraineeDao extends CrudRepository<Trainee, Integer> {

}

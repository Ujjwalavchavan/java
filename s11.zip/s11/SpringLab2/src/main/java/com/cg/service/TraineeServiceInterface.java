package com.cg.service;

import com.cg.entity.Trainee;

public interface TraineeServiceInterface {

	void saveTrainee(Trainee trainee);

	Trainee getTrainee(int id);

	Iterable<Trainee> getAll();

	public String deleteTrainee(Trainee trainee);

	public Trainee updateTrainee(Trainee trainee, int id);

}

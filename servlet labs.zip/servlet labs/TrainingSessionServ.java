package cg.servlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import cg.bean.TrainingBean;
import cg.service.ITrainingService;
import cg.service.TrainingService;

@WebServlet(name = "TrainingSession", urlPatterns = { "/TrainingSession" })
public class TrainingSessionServ extends HttpServlet {
	private static final long serialVersionUID = 1L;

	ITrainingService service;

	@Override
	public void init() throws ServletException {
		service = new TrainingService();
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		List<TrainingBean> allTrainingData = service.showAll();

		HttpSession session = request.getSession();

		if (request.getParameter("id").equals("load")) {
			session.setAttribute("data", allTrainingData);
			request.getRequestDispatcher("TrainingSession.jsp").forward(
					request, response);
		} else {
			int id = Integer.parseInt(request.getParameter("id"));
			TrainingBean tb = allTrainingData.stream()
					.filter(x -> x.getTrainingId() == id).findFirst().get();

			tb = service.enroll(tb);
			response.sendRedirect("TrainingSession.jsp?enrolled="
					+ tb.getTrainingName());
		}
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
	}

}

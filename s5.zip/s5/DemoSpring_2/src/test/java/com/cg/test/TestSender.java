package com.cg.test;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.anno.Producer;
public class TestSender {
@Test
public void testProcess() {
	//ApplicationContext ctx=new ClassPathXmlApplicationContext("sender.xml");
	ApplicationContext ctx=new ClassPathXmlApplicationContext("annotated.xml");
	
	//this statement returns the object(values) of the map that is present in sender.xml 
	Producer p=(Producer)ctx.getBean("prod");//instantiates the bean(eager instantiation)
	
	p.process("sms", "9029519704", "Hello There");
	p.process("mail", "ujjwalachavan@gmail.com", "Hey There");
	p.process("wap", "kisko", "pata nahi");
	
}
}

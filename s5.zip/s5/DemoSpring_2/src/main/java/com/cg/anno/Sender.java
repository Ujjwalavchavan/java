package com.cg.anno;

public interface Sender {
	void send(String to, String msg);

}

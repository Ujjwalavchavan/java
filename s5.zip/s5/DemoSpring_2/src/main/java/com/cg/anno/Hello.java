package com.cg.anno;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("hi")//creating bean
public class Hello {
	private String greeting;

	public Hello() {

	}

	public Hello(String greeting) {

		this.greeting = greeting;
	}

	public String getGreeting() {
		return greeting;
	}
	@Value("Hello Spring")//value injection
	public void setGreeting(String greeting) {
		this.greeting = greeting;
	}

}

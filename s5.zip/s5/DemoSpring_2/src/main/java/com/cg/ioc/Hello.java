package com.cg.ioc;

public class Hello {
	private String greeting;

	public Hello() {

	}

	public Hello(String greeting) {

		this.greeting = greeting;
	}

	public String getGreeting() {
		return greeting;
	}

	public void setGreeting(String greeting) {
		this.greeting = greeting;
	}

}

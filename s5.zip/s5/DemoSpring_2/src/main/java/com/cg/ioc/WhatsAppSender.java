package com.cg.ioc;

public class WhatsAppSender implements Sender {

	public WhatsAppSender() {
		System.out.println("WhatsAppSender is ready");
	}

	public void send(String to, String msg) {
		System.out.println("WhatsApp:" + msg + " send to " + to);
	}

}

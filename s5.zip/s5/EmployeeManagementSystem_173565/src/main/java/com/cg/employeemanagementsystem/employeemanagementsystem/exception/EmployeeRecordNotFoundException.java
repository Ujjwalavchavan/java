//Package name
package com.cg.employeemanagementsystem.employeemanagementsystem.exception;

public class EmployeeRecordNotFoundException extends Exception{
	//Default Constructor
	public EmployeeRecordNotFoundException()
	{
		
	}
	//Parameterized  Constructor 
	public EmployeeRecordNotFoundException(String message)
	{
		super(message);
	}

}

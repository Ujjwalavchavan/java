//Package Name
package com.cg.employeemanagementsystem.employeemanagementsystem.service;

import com.cg.employeemanagementsystem.employeemanagementsystem.entity.Employee;
import com.cg.employeemanagementsystem.employeemanagementsystem.exception.EmployeeRecordNotFoundException;

public interface EmployeeServiceInterface {
	
	//Method Declarations For Required Functionalities

	void saveEmployee(Employee employee);

	Employee getEmployeeById(int employeeId) throws EmployeeRecordNotFoundException;

	Employee updateEmployee(Employee employee, int employeeId);

	String deleteEmployee(int employeeId);

	Iterable<Employee> getAllEmployee();
}

//Package Name
package com.cg.employeemanagementsystem.employeemanagementsystem.rest;

//Required imports 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.employeemanagementsystem.employeemanagementsystem.entity.Employee;
import com.cg.employeemanagementsystem.employeemanagementsystem.exception.EmployeeRecordNotFoundException;
import com.cg.employeemanagementsystem.employeemanagementsystem.service.EmployeeServiceInterface;

@RestController
public class EmployeeController {
	@Autowired // Injecting Service Interface
	private EmployeeServiceInterface employeeServiceInterface;

	// For creating new employee record
	@PostMapping(path = "/add", consumes = "application/json")
	public String saveEmployee(@RequestBody Employee employee) {
		employeeServiceInterface.saveEmployee(employee);
		return "Employee  Details  Saved  Successfully";
	}

	// For updating employee record
	@PutMapping(path = "/update/{empId}", consumes = "application/json")
	public Employee updateEmployee(@PathVariable("empId") int empId, @RequestBody Employee employee) {
		return employeeServiceInterface.updateEmployee(employee, empId);

	}

	// For Getting Employee by Employee id
	@GetMapping(name = "/employee", produces = "application/json")
	public Employee getEmployee(@RequestParam("empId") int empId) throws EmployeeRecordNotFoundException {
		
		Employee employee = employeeServiceInterface.getEmployeeById(empId);
		return employee;
	}

	// For Deleting Employee
	@DeleteMapping(path = "/delete/{empId}")
	public String deleteEmployee(@PathVariable("empId") int empId) {
		return employeeServiceInterface.deleteEmployee(empId);
	}

	// For Displaying All Employees
	@GetMapping("/all")
	public Iterable<Employee> getAll() {
		return employeeServiceInterface.getAllEmployee();
	}

}

package com.cg.employeemanagementsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeManagementSystem173565Application {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeManagementSystem173565Application.class, args);
	}

}

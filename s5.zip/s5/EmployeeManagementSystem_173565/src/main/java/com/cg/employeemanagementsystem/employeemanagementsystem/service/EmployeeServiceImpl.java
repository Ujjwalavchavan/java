//Package Name
package com.cg.employeemanagementsystem.employeemanagementsystem.service;

//Required imports
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.employeemanagementsystem.employeemanagementsystem.entity.Employee;
import com.cg.employeemanagementsystem.employeemanagementsystem.exception.EmployeeRecordNotFoundException;
import com.cg.employeemanagementsystem.employeemanagementsystem.repo.EmployeeRepoInterface;


@Transactional
@Service("service")
public class EmployeeServiceImpl implements EmployeeServiceInterface {

	// Injecting EmployeeRepoInterface
	@Autowired
	private EmployeeRepoInterface employeeRepoInterface;

	// For creating new employee record
	@Override
	public void saveEmployee(Employee employee) {
		employeeRepoInterface.save(employee);

	}

	// For Getting Employee by Employee id
	@Override
	public Employee getEmployeeById(int employeeId) throws EmployeeRecordNotFoundException {
		try {
			return employeeRepoInterface.findById(employeeId).get();
		} catch (Exception e) {
			throw new EmployeeRecordNotFoundException("No Employee record Found for:"+employeeId);
		}

	}

	// For updating employee record
	@Override
	public Employee updateEmployee(Employee employee, int employeeId) {
		employee.setEmpId(employeeId);
		employeeRepoInterface.save(employee);
		return employee;
	}

	// For Deleting Employee
	@Override
	public String deleteEmployee(int employeeId) {
		Employee employee = employeeRepoInterface.findById(employeeId).get();
		employeeRepoInterface.delete(employee);
		return "Record Delete Successfully";
	}

	// For Displaying All Employees
	@Override
	public Iterable<Employee> getAllEmployee() {

		return employeeRepoInterface.findAll();
	}

}

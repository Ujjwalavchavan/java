//Package Name
package com.cg.employeemanagementsystem.employeemanagementsystem.entity;

//Required Imports
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity // This annotation defines the class as an entity
@Table(name = "Employee") // Name of the table in database
public class Employee {

	// Defining Data members
	@Id // Define this variable as primary key in table
	@Column(name = "empid", length = 20) // defining the name and length of attribute in table
	@GeneratedValue // For id auto generation
	private int empId;
	@Column(name = "name", length = 20)
	private String employeeName;
	@Column(name = "designation", length = 20)
	private String employeeDesignation;
	@Column(name = "salary")
	private double employeeSalary;
	@Column(name = "deptname", length = 25)
	private String employeeDepartment;

	// Generating getters and setters
	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getEmployeeDesignation() {
		return employeeDesignation;
	}

	public void setEmployeeDesignation(String employeeDesignation) {
		this.employeeDesignation = employeeDesignation;
	}

	public double getSalary() {
		return employeeSalary;
	}

	public void setSalary(double salary) {
		this.employeeSalary = salary;
	}

	public String getEmployeeDepartment() {
		return employeeDepartment;
	}

	public void setEmployeeDepartment(String employeeDepartment) {
		this.employeeDepartment = employeeDepartment;
	}

}

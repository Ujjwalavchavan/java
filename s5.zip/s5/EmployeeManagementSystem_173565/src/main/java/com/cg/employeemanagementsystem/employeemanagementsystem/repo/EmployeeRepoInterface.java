//Package Name
package com.cg.employeemanagementsystem.employeemanagementsystem.repo;

//Required imports
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cg.employeemanagementsystem.employeemanagementsystem.entity.Employee;
//@Repository
public interface EmployeeRepoInterface extends CrudRepository<Employee, Integer> {

}

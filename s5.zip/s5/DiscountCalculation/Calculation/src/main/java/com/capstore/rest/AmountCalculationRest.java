package com.capstore.rest;

/**
 * This is a RestController class for AmountCalculation
 * @author Ujjwala Chavan
 * @version 1.0.0
 */
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.capstore.service.AmountCalculationService;

@RestController
public class AmountCalculationRest {

	@Autowired
	private AmountCalculationService calculationService;

	@GetMapping(name = "/CouponDiscountAmount", produces = "application/json")
	public double calculateCoupon(@RequestParam("price") double price, @RequestParam("discountPrice") double discountPrice) {
		double coupon = calculationService.CouponCalculation(price, discountPrice);
		return coupon;

	}

	@GetMapping(name = "/PromoDiscountAmount", produces = "application/json")
	public double calculatePromo(@RequestParam("price") double price, @RequestParam("discountAmount") double discountAmount) {
		double promo = calculationService.PromoCalculation(price, discountAmount);
		return promo;

	}

}
package com.capstore.repo;
/**
 * This is a Repo class for AmountCalculation
 * @author Ujjwala Chavan
 * @version 1.0
 */
import org.springframework.data.repository.CrudRepository;

import com.capstore.bean.Promo;

public interface AmountCalculationRepo extends CrudRepository<Promo, Long> {

}

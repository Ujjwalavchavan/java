package com.capstore.service;

/**
 * This is a service class for AmountCalculation
 * @author Ujjwala Chavan
 * @version 1.0.0
 */
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.capstore.bean.Coupon;
import com.capstore.bean.Promo;
import com.capstore.bean.Inventory;
import com.capstore.repo.AmountCalculationRepo;

@Repository
@Transactional
public class AmountCalculationServiceImpl implements AmountCalculationService {

	@Autowired
	AmountCalculationRepo repoInterface;

	Inventory inventory;
	Promo promo;
	Coupon couponInfo;

	double finalAmount;
	double discountAmount;
	double couponPrice;

	@Override
	public double CouponCalculation(double price, double discountPrice) {
		couponPrice = price - discountPrice;
		couponInfo.setIsUsed("yes");
		return couponPrice;
	}

	@Override
	public double PromoCalculation(double price, double discountAmount) {
		discountAmount = (promo.getDiscountAmount() * inventory.getPrice()) / 100;
		finalAmount = inventory.getPrice() - discountAmount;
		return finalAmount;

	}

}

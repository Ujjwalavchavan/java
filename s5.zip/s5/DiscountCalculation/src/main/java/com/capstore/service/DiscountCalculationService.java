package com.capstore.service;

public interface DiscountCalculationService {

	// calculating discount on an product
	double PromoCalculation(double price, double discountAmount);

}

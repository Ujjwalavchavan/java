package com.capstore.service;

/**
 * This is a service class for DiscountCalculation
 * @author Ujjwala Chavan
 * @version 1.0.0
 */
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.capstore.repo.DiscountCalculationRepo;

@Repository
@Transactional
public class DiscountCalculationServiceImpl implements DiscountCalculationService {

	@Autowired
	DiscountCalculationRepo repoInterface;

	double finalAmount;
	double discountAmount;
	double couponPrice;

	@Override
	public double PromoCalculation(double price, double discountAmount) {
		discountAmount = (discountAmount * price) / 100;
		finalAmount = price - discountAmount;
		return finalAmount;

	}

}

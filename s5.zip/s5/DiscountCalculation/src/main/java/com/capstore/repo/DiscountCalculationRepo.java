package com.capstore.repo;
/**
 * This is a Repo class for DiscountCalculation
 * @author Ujjwala Chavan
 * @version 1.0
 */
import org.springframework.data.repository.CrudRepository;

import com.capstore.bean.Promo;

public interface DiscountCalculationRepo extends CrudRepository<Promo, Long> {

}

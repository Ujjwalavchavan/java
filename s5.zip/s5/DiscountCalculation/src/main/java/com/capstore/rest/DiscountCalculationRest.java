package com.capstore.rest;

/**
 * This is a RestController class for DiscountCalculation
 * @author Ujjwala Chavan
 * @version 1.0.0
 */
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.capstore.service.DiscountCalculationService;

@RestController
public class DiscountCalculationRest {

	@Autowired
	private DiscountCalculationService calculationService;

	@GetMapping(name = "/PromoDiscountAmount", produces = "application/json")
	public double calculatePromo(@RequestParam("price") double price,
			@RequestParam("discountAmount") double discountAmount) {
		double promo = calculationService.PromoCalculation(price, discountAmount);
		return promo;

	}

}
package com.cg.test;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


import com.cg.ioc.Sbu;

public class TestEmployee {
	@Test
	public void testClient() {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("employee.xml");
		Sbu sbu=(Sbu) ctx.getBean("sbu");
		assertNotNull("Null Object", sbu);
		System.out.println(sbu.toString());
		//Employee employee = (Employee) ctx.getBean("emp");
//		assertNotNull("Null Object", employee);
//		System.out.println(employee.toString());
	}

}

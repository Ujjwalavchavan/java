package com.cg;

import java.util.ArrayList;
import java.util.Scanner;





public class ExecutorMain {
	public static void main(String[] args) {
	
	int employeeId = 0;
	Scanner sc=new Scanner(System.in);
	
	EmployeeService employeeService=new EmployeeService();


	
		System.out.println("Enter your id:");
		employeeId=sc.nextInt();
		

		employeeService.getDetails(employeeId);
		
//		System.out.println("Details :"+ e1.toString());
	
	
}
}


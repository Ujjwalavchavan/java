package com.cg.ioc;

public class Employee {
	int empId;
	String empName;
	double empSalary;
	String empBusinessUnit;
	int empAge;
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public double getEmpSalary() {
		return empSalary;
	}
	public void setEmpSalary(double empSalary) {
		this.empSalary = empSalary;
	}
	public String getEmpBusinessUnit() {
		return empBusinessUnit;
	}
	public void setEmpBusinessUnit(String empBusinessUnit) {
		this.empBusinessUnit = empBusinessUnit;
	}
	public int getEmpAge() {
		return empAge;
	}
	public void setEmpAge(int empAge) {
		this.empAge = empAge;
	}
	
	@Override
	public String toString() {
		return "Employee [emp Id=" + empId + ", emp Name=" + empName + ", emp Salary=" + empSalary + ", emp BusinessUnit="
				+ empBusinessUnit + ", emp Age=" + empAge + "]";
	}
	
	
	
	

}

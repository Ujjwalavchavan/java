package com.cg.ioc;

public class Employee {
	int empId;
	String empName;
	double empSalary;
	int empAge;
	Sbu empBusinessUnit;

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public double getEmpSalary() {
		return empSalary;
	}

	public void setEmpSalary(double empSalary) {
		this.empSalary = empSalary;
	}

	public int getEmpAge() {
		return empAge;
	}

	public void setEmpAge(int empAge) {
		this.empAge = empAge;
	}

	public Sbu getEmpBusinessUnit() {
		return empBusinessUnit;
	}

	public void setEmpBusinessUnit(Sbu empBusinessUnit) {
		this.empBusinessUnit = empBusinessUnit;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empSalary=" + empSalary + ", empAge=" + empAge
				+ ", empBusinessUnit=" + empBusinessUnit + "]";
	}

}

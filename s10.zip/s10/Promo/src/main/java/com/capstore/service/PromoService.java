package com.capstore.service;

import com.capstore.entity.Promo;


public interface PromoService {
	
    void savePromo(Promo promo);
	
	Promo get(int promo_id);
	
	Iterable<Promo> getAll();

}

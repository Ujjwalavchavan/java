package com.capstore.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capstore.entity.Promo;
import com.capstore.service.PromoService;


@RestController
public class PromoController {
	@Autowired
	private PromoService service;

	@GetMapping("/hi")
	public String get() {
		return "Hi from CapStore";
	}

	@GetMapping("/all")
	public Iterable<Promo> geAll() {
		return service.getAll();
	}
	
	// Add new Promo to DB
	@PostMapping(path = "/add", consumes = "application/json")
	public String savePromo(@RequestBody Promo promo) {

		service.savePromo(promo);

		return "Promo Saved Successfully";
	}
}

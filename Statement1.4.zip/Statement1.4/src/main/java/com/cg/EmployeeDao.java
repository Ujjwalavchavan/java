package com.cg;

import java.util.HashMap;
import java.util.Map;

public class EmployeeDao {
	Map<Integer, Employee> map = new HashMap<Integer, Employee>();

	public void getValues(int employeeId) {
		Employee e=new Employee();
		
		map.put(100, e);
	}
}

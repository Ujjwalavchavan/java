package com.cg;

import com.cg.EmployeeDao;

public class EmployeeService {
	int employeedId;
	EmployeeDao employeeDao = new EmployeeDao();

	public void getDetails(int employeeId) {

		employeeDao.getValues(employeeId);

	}

}

package com.cg.test;

import static org.junit.Assert.assertNotNull;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.Employee;



public class EmployeeTest {
	
	@Test
	public void testGetObject() {
		
		Scanner sc=new Scanner(System.in);
		ApplicationContext ctx=new ClassPathXmlApplicationContext("beans.xml");
		Employee e=(Employee) ctx.getBean("emp1");
		assertNotNull("Null Object",e);
		
		System.out.println("Enter your id:");
		int employeeId=sc.nextInt();
		
		System.out.println("Employee Info:\n"+e);
		

	}
	
	
}


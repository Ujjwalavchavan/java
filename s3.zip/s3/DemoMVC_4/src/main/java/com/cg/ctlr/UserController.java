package com.cg.ctlr;

import java.util.ArrayList;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Scope("session")
@Controller 
@RequestMapping(value="user")

public class UserController {
	ArrayList<String> cityList;

	@RequestMapping(value = "showLogin")
	public String prepareLogin(Model model) {
		Login log = new Login();
		log.setUserName("Ujjwala");
		model.addAttribute("login", log);

		return "login";
	}
	

	@RequestMapping(value="checkLogin")
	public String checkLogin(Model model,Login login)
	{
	 //Logic to validate userName and password against database
	 

	 if(login.getUserName().equals("Ujjwala") && login.getPassword().equals("7890") )
	 {
	   return "loginSuccess"; 
	}else {
	 model.addAttribute("alert", "invalid password or username");
	 return "login";
	}
	 }

	@RequestMapping(value = "showRegister")
	public String prepareRegister(Model model) {
		model.addAttribute("user", new User());
	
		
		cityList = new ArrayList<String>();
		
			cityList.add("Mumbai");
			cityList.add("Bangalore");
			cityList.add("Chennai");
			cityList.add("Delhi");
			
			ArrayList<String> skillList = new ArrayList<String>();
			
			skillList.add("Java");
			skillList.add("Struts");
			skillList.add("Spring");
			skillList.add("Hibernate");
			
			model.addAttribute("cityList", cityList);
			model.addAttribute("skillList",skillList);
			
			model.addAttribute("user",new User());
		    return "register";	
		}
	

	@RequestMapping(value = "checkRegister")
	public String checkRegister(User user, Model model) {
		model.addAttribute("user", user);
		return "registerSuccess";
	}

}

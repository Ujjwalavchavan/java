import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit{
    userid:string;
    password:string;
    submitted: boolean=false;
    msg:string;
 validate()
 {
   if(this.userid=="ujjwala" && this.password=="chavan"){
      this.submitted=true;
      console.log(this.userid+"="+this.password);
      console.log(this.msg="Login Successfull");
     
     }
   
   else{
     
    console.log(this.msg="Enter correct credentials");
   }
 
 }

 ngOnInit() {
}

}
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-data',
  templateUrl: './data.component.html',
  styleUrls: ['./data.component.css']
})
export class DataComponent  {

  firstname:string="Ujjwala";
  lastname:string="Chavan";
  age:number=24;
 gender:string="female";

}

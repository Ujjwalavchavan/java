package com.cg.jpacrud.service;

import com.cg.jpacrud.entities.Author;

public interface AuthorService {

	public abstract void insert(Author author);
	public abstract void update(Author author);
	public abstract void delete(Author author);
	public abstract Author findById(int id); 
	
}

package com.cg.jpacrud.client;

import com.cg.jpacrud.entities.Author;
import com.cg.jpacrud.service.AuthorService;
import com.cg.jpacrud.service.AuthorServiceImpl;

public class AuthorMain {
public static void main(String[] args) {
	


	AuthorService authorService =new AuthorServiceImpl();
	Author author = new Author();
	int id=(int)(Math.random()*101);
	author.setAuthorId(id);
	author.setPhoneNo("9029519704");
	author.setFirstName("Ujjwala");
	author.setMiddleName("vishwas");
	author.setLastName("Chavan");
	
	authorService.insert(author);
	

	author=authorService.findById(id);
	System.out.println("ID:"+author.getAuthorId());
	System.out.println("FirstName:"+author.getFirstName());
	System.out.println("MiddleName:"+author.getMiddleName());
	System.out.println("LastName:"+author.getLastName());

	author.setMiddleName("Neelam");//updating 
	authorService.update(author);

	author = authorService.findById(id);
	System.out.println("ID:"+author.getAuthorId());
	System.out.println("FirstName:"+author.getFirstName());
	System.out.println("MiddleName:"+author.getMiddleName());
	System.out.println("LastName:"+author.getLastName());
	
	
	//authorService.delete(author);
	//System.out.println("Record is deleted");

	//System.out.println("End of program...");
}
}

package com.cg.step;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.bean.UserBean;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class EquipmentStepDefinition {
	WebDriver driver;
	UserBean user;

	@Before
	public void init() {
		// instantiate driver
		System.setProperty("webdriver.chrome.driver", "mydriver\\chromedriver.exe");

		driver = new ChromeDriver();
	}

	@After
	public void destroy() {
		driver.quit();
	}

	@Given("^user is on home page$")
	public void user_is_on_home_page() throws Throwable {
		String url = "file:///C:\\Users\\ujchavan\\Desktop\\ujjwala\\Module3\\Bdd\\EquipmentTrackingSystem\\html/login.html";
		driver.get(url);
		user = new UserBean();
		PageFactory.initElements(driver, user);
		Thread.sleep(3000);
	}

	@When("^user selects radio box$")
	public void user_selects_radio_box() throws Throwable {
		user.selectUser(0);
	}

	@Then("^validate radio box$")
	public void validate_radio_box() throws Throwable {

		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(3000);
	}

}

package com.cg.bean;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class UserBean {
	
	@FindBy(id = "inventorypersonnel")
	private WebElement inventoryPersonnel;
	
	@FindBy(id = "equipmentauditors")
	private WebElement equipmentAuditors;
	
	@FindBy(id = "servicepersonnel")
	private WebElement servicePersonnel;
	
	@FindBy(id = "maintenancepersonnel")
	private WebElement maintenancePersonnel ;
	
	@FindBy(id = "equipmenttrackingpersonnel")
	private WebElement equipmenttrackingpersonnel ;
	
	@FindBy(id="user")
	private List<WebElement> user;
	
	 public void selectUser(int idx) {
		 this.user.get(idx).click();
	 }	 
}

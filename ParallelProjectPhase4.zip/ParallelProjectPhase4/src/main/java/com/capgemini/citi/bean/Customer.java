package com.capgemini.citi.bean;

import java.io.Serializable;


import javax.persistence.*;

import org.springframework.stereotype.Component;
@Entity
@Component
@Table(name="customer99")
public class Customer implements Serializable{
	
	@Column(length=20)
	private String Name;
	private String email;
	@Id
	private long mobileNo;
	private double balance;
//	private String address;
	private double custId;
	//private String username;
	private String password;
	
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Long getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	public double getCustId() {
		return custId;
	}
	public void setCustId(double custId) {
		this.custId = custId;
	}
	
	
	
	@Override
	public String toString() {
		return "Customer [Name=" + Name + ", email=" + email + ", mobileNo="
				+ mobileNo + ", balance=" + balance + " "
				+ ", custId=" + custId + "]";
	}
	public Customer(String name, String email, long mobileNo, double balance,
			String password) {
		super();
		Name = name;
		this.email = email;
		this.mobileNo = mobileNo;
		this.balance = balance;
		this.password = password;
	}
	public Customer() {
		super();
	}

}

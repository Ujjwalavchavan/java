package com.capgemini.citi.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="transaction786")
public class TransactionEntries {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private String type;
	private double amount,balance;
	private long mobNo;
	public TransactionEntries(String type, double amount, double balance,long mobNo) {
		super();
		this.type = type;
		this.amount = amount;
		this.balance = balance;
		this.mobNo = mobNo;
		//this.mobNo = mobNo;
	}
	
	

	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public long getMobNo() {
		return mobNo;
	}
	public void setMobNo(long mobNo) {
		this.mobNo = mobNo;
	}
	@Override
	public String toString() {
		return "TransactionEntries [type=" + type + ", amount=" + amount + ", balance=" + balance + ", mobNo=" + mobNo
				+ "]";
	}

	public TransactionEntries() {
	
	}
	
	
	

}

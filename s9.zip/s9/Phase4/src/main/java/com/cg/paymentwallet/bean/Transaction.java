package com.cg.paymentwallet.bean;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("recordTrans")
@Scope("prototype")

public class Transaction {
	
	//Constructors
	public Transaction(int transId, String type, String amount, String balance) {
		super();
		this.transId = transId;
		this.type = type;
		this.amount = amount;
		this.balance = balance;
	}

	public Transaction() {
		super();
		// TODO Auto-generated constructor stub
	}

	//declaring constants 
	private int transId;
	public String type;
	private String amount,balance;

	//Getters & setters
	public int getTransId() {
		return transId;
	}

	public void setTransId(int transId) {
		this.transId = transId;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getBalance() {
		return balance;
	}

	public void setBalance(String balance) {
		this.balance = balance;
	}

	//to print all transaction
	@Override
	public String toString() {
		return "Transaction [transId=" + transId + ", type=" + type + ", amount=" + amount + ", balance=" + balance
				+ "]";
	}
}

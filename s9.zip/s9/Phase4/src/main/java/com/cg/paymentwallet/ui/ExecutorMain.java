package com.cg.paymentwallet.ui;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

import com.cg.paymentwallet.bean.Customer;
import com.cg.paymentwallet.exception.IdNotFoundException;
import com.cg.paymentwallet.exception.InsufficientBalanceException;
import com.cg.paymentwallet.service.ServiceInterface;

@Component
public class ExecutorMain {

	public static void main(String[] args){
		
		ApplicationContext context = new ClassPathXmlApplicationContext("annotated.xml");
		
		ServiceInterface service = (ServiceInterface) context.getBean("service");

		System.out.println("Welcome to Bank Application");
		Customer c = new Customer();
		Scanner scan = new Scanner(System.in);
		int choice;
			
			do{
				System.out.println("1.Create New Account\t"
						+ "2:Show Balance\t3:Deposite\t4:Withdraw\t5:Fund Transfer\t"
						+ "6:Print Transaction\t7:Exit");
				System.out.println("Enter your choice:");
				choice = scan.nextInt();
				switch(choice){
				case 1: //mainClass.createAccount();
				// taking name from user
				System.out.println("Enter name");

				while (true) {
					String name1 = scan.next();
					boolean isValid = service.validName(name1);
					if (isValid) {
						c.setName(name1);
						break;
					} else {
						System.out.println("Enter name with first capital letter and minimum length 6");
					}
				}
				
				//taking mobile number from user
				System.out.println("Enter mobile number");
				while(true){
					String number = scan.next();
					boolean isValid = service.validNumber(number);
					if(isValid){
						c.setMobile(number);
						break;
					}
					else{
						System.out.println("Enter 10 digits number only");
					}
				}
				
				//taking email from user
				System.out.println("Enter email");
				while(true){
					String email = scan.next();
					boolean isValid = service.validEmail(email);
					if(isValid){
						c.setEmail(email);
						break;
					}
					else{
						System.out.println("Enter email in valid format");
					}
				}
				
				//taking amount from user
				System.out.println("Enter amount");
				while(true){
					String amount = scan.next();
					boolean isValid = service.validAmount(amount);
					if(isValid){
						c.setBalance(amount);
						break;
					}
					else{
						System.out.println("Enter numbers only");
					}
				}
						boolean success = service.insert(c);
						if(success)
							System.out.println("Customer account created successfully.");
						else
							System.out.println("Something got wrong.");
						break;
						
				case 2: System.out.println("Enter customer id");
						String id;
						//validate customer id
						while(true){
							id = scan.next();
							boolean isValid = service.validId(id);
							if(isValid)
								break;
							else
								System.out.println("Enter numbers only");
						}
						
						long custId = Long.parseLong(id);
						c.setCustId(custId);
						String balance= null;
						try{
							balance = service.showBalance(c.getCustId());
							System.out.println("Available Balance:"+balance);
						}catch(IdNotFoundException e){
							System.out.println(e.getMessage());
						}
						break;
					
				case 3: System.out.println("Enter customer id");
						String custId1;
						// validate customer id
						while (true) {
							custId1 = scan.next();
							boolean isValid = service.validId(custId1);
							if (isValid)
								break;
							else
								System.out.println("Enter numbers only");
						}
						System.out.println("Enter amount to deposite");

						String amount;
						while(true){
							amount = scan.next();
							boolean isValid = service.validAmount(amount);
							if(isValid){
								break;
							}
							else{
								System.out.println("Enter numbers only");
							}
						}
						
						try{
							balance = service.deposite(custId1, amount);
							System.out.println(amount+" amount credited successfully");
							System.out.println("Available Balance: "+balance);
						}catch(IdNotFoundException e){
							System.out.println(e.getMessage());
						}
						break;
					
				case 4: String withdrawBalance = null;
						System.out.println("Enter customer id");

						// validate customer id
						while (true) {
							custId1 = scan.next();
							boolean isValid = service.validId(custId1);
							if (isValid)
								break;
							else
								System.out.println("Enter numbers only");
						}
						
						System.out.println("Enter amount to withdraw");

						//validate amount
						String amount1;
						while(true){
							amount1 = scan.next();
							boolean isValid = service.validAmount(amount1);
							if(isValid){
								break;
							}
							else{
								System.out.println("Enter numbers only");
							}
						}
						
						try{
							withdrawBalance = service.withdraw(custId1,amount1);
							System.out.println(amount1+" amount debited successfully");
							System.out.println("Available Balance: "+withdrawBalance);
						}catch(InsufficientBalanceException  e){
							System.out.println(e.getMessage());
						}catch (IdNotFoundException e) {
							System.out.println(e.getMessage());
						}
						break;
						
				case 5: String transferAmount = null;
						System.out.println("Enter sender id");

						// validate customer id
						String senderId;
						while (true) {
							senderId = scan.next();
							boolean isValid = service.validId(senderId);
							if (isValid)
								break;
							else
								System.out.println("Enter numbers only");
						}
						
						System.out.println("Enter reciepent id");
						
						// validate customer id
						String receiverId;
						while (true) {
							receiverId = scan.next();
							boolean isValid = service.validId(receiverId);
							if (isValid)
								break;
							else
								System.out.println("Enter numbers only");
						}
						
						System.out.println("Enter amount to transfer");
						amount1 = scan.next();
						//amount1 = mainClass.valid();
						try{
							transferAmount = service.fundTransfer(senderId,receiverId,amount1);
							System.out.println(amount1+" amount trasfered successfully");
							System.out.println("Available Balance: "+transferAmount);
						}catch(InsufficientBalanceException  e){
							System.out.println(e.getMessage());
						}catch (IdNotFoundException e) {
							System.out.println(e.getMessage());
						}
						
						break;
				
				case 6: service.printTransaction();
						break;
						
				case 7: System.out.println("Visit Again..Thank you");
						System.exit(0);
						
				default: System.out.println("Wrong choice");
				}
			}while(choice!=7);
		}

	
	
}

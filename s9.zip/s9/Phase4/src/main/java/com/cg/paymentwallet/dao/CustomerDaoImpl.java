package com.cg.paymentwallet.dao;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Repository;

import com.cg.paymentwallet.bean.Customer;
import com.cg.paymentwallet.bean.Transaction;
import com.cg.paymentwallet.exception.IdNotFoundException;
import com.cg.paymentwallet.exception.InsufficientBalanceException;

@Repository("dao")
public class CustomerDaoImpl implements CustomerDao {

	@Autowired
	ApplicationContext context;
	Customer cust = new Customer();
	int transId=1000;
	Map<Long,Customer> customerEntry;
	Map<Integer,Transaction> transactionEntry;
	
	public CustomerDaoImpl() {
		
		customerEntry = new HashMap<Long,Customer>();
		
		transactionEntry =new HashMap<Integer,Transaction>();
	}
	
	//insert into Map
	public boolean insert(Customer c){
		//generating random no. for customerId an set
		long custId = (long)(Math.random()*10000);
		c.setCustId(custId);
		customerEntry.put(custId, c);
		System.out.println("Account created successfully.");
		System.out.println("Your details are as follows:");
		System.out.println("Customer Id: "+c.getCustId()+"\tName: "+c.getName()+
				"\tMobile: "+c.getMobile()+"\tEmail: "+c.getEmail()+"\tBalance: "+c.getBalance());
		
		// store new account created info in transaction
		Transaction recordTrans = (Transaction) context.getBean(Transaction.class);
		recordTrans.setTransId(++transId);
		recordTrans.setType("CR");
		recordTrans.setAmount(c.getBalance());
		recordTrans.setBalance(c.getBalance());
		transactionEntry.put(transId,recordTrans);

		return true;
	}

	//method to display balance 
	public String showBalance(long custId)throws IdNotFoundException{
		String balance = null;
		if(customerEntry.containsKey(custId)) {
			Customer c1 = new Customer();
			c1 = customerEntry.get(custId);
			balance = c1.getBalance();
		}else {
			throw new IdNotFoundException("customer Id is not found");
		}
		return balance;
	}
	
	//method to deposit amount
	public String deposite(String custId, String amount)throws IdNotFoundException {
		String balance;
		if(customerEntry.containsKey(Long.parseLong(custId))) {
			Customer c1 = new Customer();
			c1 = customerEntry.get(Long.parseLong(custId));
		
			long balance1 = Long.parseLong(amount)+(Long.parseLong(c1.getBalance()));
			balance = String.valueOf(balance1);
			c1.setBalance(balance);
			
			// store deposit info in transaction 
			Transaction recordTrans = (Transaction) context.getBean(Transaction.class);
			recordTrans.setTransId(++transId);
			recordTrans.setType("CR");
			recordTrans.setAmount(amount);
			recordTrans.setBalance(c1.getBalance());
			transactionEntry.put(transId,recordTrans);
		}else {
			throw new IdNotFoundException("customer Id is not found");
		}
		
		return balance;
	}

	//method to withdraw amount
	public String withdraw(String custId, String amount)throws InsufficientBalanceException,IdNotFoundException {
		String balance;
		if(customerEntry.containsKey(Long.parseLong(custId))) {
			Customer c1;
			c1 = customerEntry.get(Long.parseLong(custId));
			long balance1 = Long.parseLong(c1.getBalance());
			if(balance1 > Long.parseLong(amount)){
				balance1-= Long.parseLong(amount);
				balance = String.valueOf(balance1);
				c1.setBalance(balance);
				
				// store withdraw information in transaction 
				Transaction recordTrans = (Transaction) context.getBean(Transaction.class);
				recordTrans.setTransId(++transId);
				recordTrans.setType("DB");
				recordTrans.setAmount(amount);
				recordTrans.setBalance(c1.getBalance());
				transactionEntry.put(transId,recordTrans);
			}else{
				throw new InsufficientBalanceException("You don't have sufficient balance to withdraw");
			}
		}else {
			throw new IdNotFoundException("customer Id is not found");
		}
		return balance;
	}

	//method for fund transfer
	public String fundTransfer(String senderId, String receiverId, String amount) throws InsufficientBalanceException, IdNotFoundException {
		String balance = null;
		if(customerEntry.containsKey(Long.parseLong(senderId)) && customerEntry.containsKey(Long.parseLong(receiverId))) {
			Customer c1 = customerEntry.get(Long.parseLong(senderId));
			long balance1 = Long.parseLong(c1.getBalance());
			if(balance1 > Long.parseLong(amount)){
				balance1-= Long.parseLong(amount);
				balance = String.valueOf(balance1);
				c1.setBalance(balance);

				// store withdraw info in transaction 
				Transaction recordTrans = (Transaction) context.getBean(Transaction.class);
				recordTrans.setTransId(++transId);
				recordTrans.setType("DB");
				recordTrans.setAmount(amount);
				recordTrans.setBalance(c1.getBalance());
				transactionEntry.put(transId,recordTrans);
				
				Customer c2 = customerEntry.get(Long.parseLong(receiverId));
				long receiverBalance = Long.parseLong(c2.getBalance());
				long rcvBal = receiverBalance + Long.parseLong(amount);
				c2.setBalance(String.valueOf(receiverBalance));

				// store deposit info in transaction 
				Transaction recordTrans1 = (Transaction) context.getBean(Transaction.class);
				recordTrans1.setTransId(++transId);
				recordTrans1.setType("CR");
				recordTrans1.setAmount(amount);
				recordTrans1.setBalance(c2.getBalance());
				transactionEntry.put(transId,recordTrans);
			}else{
				throw new InsufficientBalanceException("Sorry You don't have enough balance to withdraw");
			}
		}else {
			throw new IdNotFoundException("customer Id is not found");
		}
		return balance;
	}

	//print all transactions
	public void printTransaction(){
		System.out.println(transactionEntry.values());
	}

	

}

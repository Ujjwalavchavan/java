package com.cg.paymentwallet.exception;

public class IdNotFoundException extends Exception {
	
	public IdNotFoundException() {
		
	}
	
	public IdNotFoundException(String message){
		super(message);
	}
}

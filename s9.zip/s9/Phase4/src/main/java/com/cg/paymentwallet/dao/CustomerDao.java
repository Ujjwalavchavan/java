package com.cg.paymentwallet.dao;

import com.cg.paymentwallet.bean.Customer;
import com.cg.paymentwallet.exception.IdNotFoundException;
import com.cg.paymentwallet.exception.InsufficientBalanceException;

public interface CustomerDao {

	//methods related to CRUD defined in CustomerDaoImpl class
		public boolean insert(Customer c);
		public String showBalance(long custId) throws IdNotFoundException;
		public String deposite(String custId, String amount)throws IdNotFoundException;
		public String withdraw(String custId, String amount)throws InsufficientBalanceException,IdNotFoundException;
		public String fundTransfer(String senderId, String receiverId, String amount) throws InsufficientBalanceException, IdNotFoundException;
		public void printTransaction();
}

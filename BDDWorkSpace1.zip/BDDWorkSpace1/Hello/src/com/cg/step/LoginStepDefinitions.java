package com.cg.step;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LoginStepDefinitions {
	private WebDriver driver;
	
	@Before
	public void init() {
		//Instantiate driver
		System.setProperty("webdriver.chrome.driver", "mydriver\\chromedriver.exe");
		   driver=new ChromeDriver();
		
	}
	
	@Given("^User is on login page$")
	public void user_is_on_login_page() throws Throwable {
		String url="file:///C:\\Users\\ujchavan\\Desktop\\ujjwala\\"
				+ "Module3\\Bdd\\Hello\\html/login.html";
		driver.get(url);
	}

	@When("^User enters username$")
	public void user_enters_username() throws Throwable {
		WebElement uname=driver.findElement(By.id("username"));
	    uname.sendKeys("ujjwala");
	}

	@Then("^Validate username$")
	public void validate_username() throws Throwable {
		
	}


	@When("^User enters password$")
	public void user_enters_password() throws Throwable {
		WebElement pwd=driver.findElement(By.id("password"));
	    pwd.sendKeys("chavan");
	}

	@Then("^Validate password$")
	public void validate_password() throws Throwable {
		
	}
	
	@When("^User submit form$")
	public void user_submit_form()throws Throwable{
		
	}
	@Then("^Show succesful alert$")
	public void show_successful_alert()throws Throwable{
		
//		driver.findElement(By.name("btnAlert")).click();
//		driver.switchTo().alert().getText();
//		Thread.sleep(5000);
//        driver.switchTo().alert().accept();
	WebElement form=driver.findElement(By.tagName("form"));
	form.submit();
	Thread.sleep(2000);
	driver.switchTo().alert().accept();
	Thread.sleep(2000);
	
}
}

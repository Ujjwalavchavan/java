package com.cg.step;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

//This example is to understand the working of feature and step definition using cucumberfor interaction

public class HelloCucumberStepDefinition {
@Before(order=1) //hook
public void init() {
	System.out.println("Scenario test starts");
}

@After //hook
public void destroy() {
	System.out.println("Scenario test ends");
}

@Before(order=0)
public void init2() {
	System.out.println("2 nd init");
}

@Given("^Attended training$")
public void attendedTraining() throws Throwable {
    System.out.println("1-Attended training"); 
  
}

@When("^clear L(\\d+)$")
public void clearL1(int arg1) throws Throwable {
    System.out.println("2-cleared L1");
}

@Then("^Become employee$")
public void become_employee() throws Throwable {
  System.out.println("I am a student"); 
}




@Given("^Hello given step$")
public void  helloGivenStep()throws Throwable{
	System.out.println("Saying hello to given step");
}

@When("^Hello when step$")
public void  helloWhenStep()throws Throwable{
	System.out.println("Saying hello to when step");
}

@Then("^Hello then step$")
public void  helloThenStep()throws Throwable{
	System.out.println("Saying hello to then step");
}



@Given("^Bye given step$")
public void  byeGivenStep()throws Throwable{
	System.out.println("Saying Bye to given step");
}

@When("^Bye when step$")
public void  byeWhenStep()throws Throwable{
	System.out.println("Saying Bye to when step");
}

@Then("^Bye then step$")
public void  byeThenStep()throws Throwable{
	System.out.println("Saying Bye to then step");
}
}

package com.cg.pizzaorder.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.exception.PizzaException;

public class PizzaOrderDAO implements IPizzaOrderDAO {

	Map<Integer, PizzaOrder> pizzaEntry = new HashMap<Integer, PizzaOrder>();
	Map<Integer, Customer> customerEntry = new HashMap<Integer, Customer>();
	double customerId, orderId;

	public int placeOrder(Customer customer, PizzaOrder pizza) {

		// auto-generating customer id
		customerId = Math.random() * 100;

		pizza.setCustomerId((int) customerId);

		customerEntry.put((int) customerId, customer);

		// auto-generating order id
		orderId = Math.random() * 100;

		pizza.setOrderId((int) orderId);

		pizzaEntry.put((int) orderId, pizza);

		return (int) orderId;
	}

	public PizzaOrder getOrderDetails(int orderId) throws PizzaException {
		boolean isOrderIdValid = false;

		for (Integer orderIdKey : pizzaEntry.keySet()) {

			if (orderIdKey == orderId) {
				isOrderIdValid = true;
				return pizzaEntry.get(orderIdKey);
			}

		}
		if (isOrderIdValid == false) {
			throw new PizzaException("Invalid order Id");
		}
		return null;

	}
}

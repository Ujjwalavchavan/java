package testQueue;
import java.util.Queue;
import java.util.LinkedList;


public class TestLinkedList {
	public static void main(String[] args) {
		
	
	Queue<String> que=new LinkedList<>();
	
	que.offer("sam");
	que.offer("nick");
	que.offer("joe");
	
		//o/p is in order
		//System.out.println(que);// we are passing object thus o/p will be in [] brackets,in line
	
	for (String node : que) {
		System.out.println(node); // this will give you o/p per new line
	}
	

}
}

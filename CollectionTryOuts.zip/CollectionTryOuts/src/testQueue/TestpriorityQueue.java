package testQueue;

import java.util.PriorityQueue;
import java.util.Queue;

public class TestpriorityQueue {
	public static void main(String[] args) {
		Queue<String> que = new PriorityQueue<>();

		que.offer("ram");
		que.offer("sham");
		que.offer("rohit");

		for (String node : que) {
			System.out.println(node);//output is in same order
		}
	}
}

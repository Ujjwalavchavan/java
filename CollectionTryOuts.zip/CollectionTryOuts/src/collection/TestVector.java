package collection;

import java.util.Iterator;
import java.util.Vector;


public class TestVector {
	public static void main(String[] args) {
		
	
	Vector<String> v= new Vector<>();
	v.add("Apple");
	v.add("Oracle");
	v.add("Google");
	v.add("Microsoft");
	v.add("Apache");
	
	
	System.out.println("--Traversing over vector using for-loop");
	for (int i = 0; i < v.size(); i++) 
		System.out.println(v.get(i));//output in same order
	
	System.out.println("--Traversing over vector using Iterartor");
	Iterator<String> itr=v.iterator();
	while(itr.hasNext())
		System.out.println(itr.next());//output in same order
	
	System.out.println("--Traversing over vector using for-each");
	for(String node:v)
		System.out.println(node);//output in same order
}
}


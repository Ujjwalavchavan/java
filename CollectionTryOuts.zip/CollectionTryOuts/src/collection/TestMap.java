package collection;

import java.util.HashMap;

public class TestMap {
	public static void main(String[] args) {
		HashMap<String, String> map=new HashMap<>();
		
		map.put("jack", "jill");
		map.put("scott", "tiger");
		map.put("java", "duke");
		map.put("jack", "rose");
	
		for(String key:map.keySet())
			//o/p is'nt in order
			System.out.println(key+":"+map.get(key));//overrides duplicate data
		
		
		//another way except for each loop
		//o/p is'nt in order
		System.out.println(map.get("scott"));
		System.out.println(map.get("java"));
		System.out.println(map.get("jack"));
}
}

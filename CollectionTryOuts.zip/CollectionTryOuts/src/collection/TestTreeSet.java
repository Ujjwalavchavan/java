package collection;

import java.util.TreeSet;


public class TestTreeSet {
	public static void main(String[] args) {

		
		TreeSet<String> tree=new TreeSet<>();
		tree.add("polo");
		tree.add("george");
		tree.add("mack");
		
		System.out.println("--Traversing over Treeset using for-each");
		for (String node : tree)
		System.out.println(node);//output is not in order as in input
		
		for (String node : tree.descendingSet())
			System.out.println(node);	//output will be in decending order according to alphabet in this case
		
		
	}
}

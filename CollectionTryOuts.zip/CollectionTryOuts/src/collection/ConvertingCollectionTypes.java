package collection;

import java.util.HashSet;
import java.util.TreeSet;
import java.util.Vector;

public class ConvertingCollectionTypes {
public static void main(String[] args) {
	Vector<String> v = new Vector<>();
	v.add("Apple");
	v.add("Oracle");
	v.add("Google");
	v.add("Microsoft");
	v.add("Apache");
	
	//storing vector in hashset
	HashSet<String> set=new HashSet<>(v);
	
	System.out.println("--Traversing over Hashset using for-each");
	for (String node : set) 
		System.out.println(node);
	
	//storing hashset in tree
	TreeSet<String> tree=new TreeSet<>(set);
	
	
	System.out.println("--Traversing over Treeset using for-each");
	for (String node : tree.descendingSet())
	System.out.println(node);
}
}

package collection;

import java.util.HashSet;

public class TestHashset {
public static void main(String[] args) {
HashSet<String> set=new HashSet<>();
	
	set.add("polo");
	set.add("mack");
	set.add("hamlet");
	
	System.out.println("--Traversing over Hashset using for-each");
	for (String node : set) 
		System.out.println(node);//output varies in order
}
}

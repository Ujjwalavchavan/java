package collection;

import java.util.ArrayList;
import java.util.Vector;

public class Merging {
	public static void main(String[] args) {
		
	
	Vector<String> v= new Vector<>();//creating vector
	v.add("Apple");
	v.add("Oracle");
	v.add("Google");
	v.add("Microsoft");
	v.add("Apache");
	
	ArrayList<String>lst =new ArrayList<String>();//creating arraylist
	v.add("Apple");
	lst.add("Facebook");
	lst.add("Amazon");
	lst.add("Google");
	
	
	v.addAll(lst);//merging collection
	
	System.out.println("--Traversing over vector using for-each");//printing
	for(String node:v)
		System.out.println(node);//output is in same order
}
}
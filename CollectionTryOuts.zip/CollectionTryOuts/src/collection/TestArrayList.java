package collection;

import java.util.ArrayList;
import java.util.Vector;

public class TestArrayList {

	public static void main(String[] args) {
		
		//String
		ArrayList<String>lst =new ArrayList<String>();
		lst.add("Facebook");
		lst.add("Amazon");
		lst.add("Google");
		
		for(String node:lst)
			System.out.println(node);//Output in same order
		
		//integer
		ArrayList<Integer> list = new ArrayList<Integer>();
		list.add(0, new Integer(42));
		int total = list.get(0).intValue(); 
		System.out.println(total);//output-42

	}
}

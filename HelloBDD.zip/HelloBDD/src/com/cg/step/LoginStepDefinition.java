//package com.cg.step;
//
//import org.openqa.selenium.By;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;
//import org.openqa.selenium.chrome.ChromeDriver;
//
//import cucumber.api.java.After;
//import cucumber.api.java.Before;
//import cucumber.api.java.en.Given;
//import cucumber.api.java.en.Then;
//import cucumber.api.java.en.When;
//
//public class LoginStepDefinition {
//	WebDriver driver;
//
//	@Before
//	public void init() {
//		// instantiate driver
//		System.setProperty("webdriver.chrome.driver", "mydriver\\chromedriver.exe");
//
//		driver = new ChromeDriver();
//	}
//	
//	@After
//	public void destroy() {
//		driver.quit();
//	}
//
//	@Given("^User is on login page$")
//	public void user_is_on_login_page() throws Throwable {
//		String url = "file:///C:\\Users\\ujchavan\\Desktop\\ujjwala\\"
//				+ "Module3\\Bdd\\Hello\\html/login.html";
//		driver.get(url);
//	}
//
//	@When("^user enters username$")
//	public void user_enters_username() throws Throwable {
//		WebElement uname = driver.findElement(By.id("username"));
//		uname.sendKeys("duke");
//
//	}
//
//	@Then("^Validate username$")
//	public void validate_username() throws Throwable {
//		WebElement login = driver.findElement(By.id("login"));
//		login.click();
//		Thread.sleep(6000);
//		driver.switchTo().alert().accept();
//		Thread.sleep(6000);
//	}
//
//	@When("^User enters password$")
//	public void user_enters_password() throws Throwable {
//		WebElement pwd = driver.findElement(By.id("password"));
//		pwd.sendKeys("java");
//	}
//
//	@Then("^Validate password$")
//	public void validate_password() throws Throwable {
//		WebElement login = driver.findElement(By.id("login"));
//		login.click();
//		Thread.sleep(6000);
//		driver.switchTo().alert().accept();
//		Thread.sleep(6000);
//	}
//
//	@When("^user submit form$")
//	public void user_submit_form() throws Throwable {
//
//	}
//
//	@Then("^show successful alert$")
//	public void show_successful_alert() throws Throwable {
//		WebElement form = driver.findElement(By.tagName("form"));
//		form.submit();
//		Thread.sleep(6000);
//		driver.switchTo().alert().accept();
//		Thread.sleep(6000);
//	}
//}

package com.cg.step;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.bean.LoginBean;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginStepDefinition2 {
	WebDriver driver;
	LoginBean login;

	@Before
	public void init() {
		// instantiate driver
		System.setProperty("webdriver.chrome.driver", "mydriver\\chromedriver.exe");

		driver = new ChromeDriver();
	}
	
	@After
	public void destroy() {
		driver.quit();
	}

	@Given("^User is on login page$")
	public void user_is_on_login_page() throws Throwable {
		String url = "file:///C:\\Users\\ujchavan\\Desktop\\ujjwala\\Module 4\\Demos\\HelloBDD\\html/login.html";
		driver.get(url);
		login=new LoginBean();
		PageFactory.initElements(driver, login);
	}

	@When("^user enters username$")
	public void user_enters_username() throws Throwable {
		login.selectUser(0);
		login.setUsername("abc");
	}

	@Then("^Validate username$")
	public void validate_username() throws Throwable {
		
		login.clickLogin();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^User enters password$")
	public void user_enters_password() throws Throwable {
		login.selectUser(0);
		login.setUsername("abcd");
		login.setPassword("123");
	}

	@Then("^Validate password$")
	public void validate_password() throws Throwable {
	
		login.clickLogin();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}
	@When("^User selects role$")
	public void user_selects_role() throws Throwable {
		login.selectUser(0);
		login.setUsername("abcd");
		login.setPassword("1234");
		login.selectRole(2);
		
	}

	@Then("^Validate Role$")
	public void validate_Role() throws Throwable {
		login.clickLogin();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000); 
	}


	@When("^user submit form$")
	public void user_submit_form() throws Throwable {
		login.selectUser(0);
		login.setUsername("abcd");
		login.setPassword("1234");
		login.selectRole(2);
	}

	@Then("^show successful alert$")
	public void show_successful_alert() throws Throwable {
		login.clickLogin();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}
	

//	@When("^user selects user$")
//	public void user_selects_user() throws Throwable {
//	   login.selectUser(0);
//	}
//
//	@Then("^Validate user$")
//	public void validate_user() throws Throwable {
//		login.clickLogin();
//		Thread.sleep(2000);
//		driver.switchTo().alert().accept();
//		Thread.sleep(2000); 
//	}
}

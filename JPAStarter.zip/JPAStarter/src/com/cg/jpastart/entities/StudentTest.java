package com.cg.jpastart.entities;

/*
 Hibernate provides implementation of JPA interfaces 
 EntityManagerFactory and EntityManager
 */
import javax.persistence.EntityManager;//Interface used to interact with the persistence context.
import javax.persistence.EntityManagerFactory;//Interface used to interact with the entity manager factory for the persistence unit.
import javax.persistence.Persistence;

public class StudentTest {

	public static void main(String[] args) {

		EntityManagerFactory factory = Persistence
				.createEntityManagerFactory("JPA-PU");//create and return an EntityManagerFactory for the named persistence unit.

		/*
		 * Create a new application-managed EntityManager. This method returns a
		 * new EntityManager instance each time it is invoked.
		 */
		EntityManager em = factory.createEntityManager();
		
		/*
		 Return the resource-level EntityTransaction object. 
		 The EntityTransaction instance may be used serially to begin and commit multiple transactions.
		 */
		em.getTransaction().begin();// it is compulsary to begin the transaction
		
		Student student = new Student();
		student.setStudentName("ujjwala");

		em.persist(student);// it is equivalent to insert query//Make an instance managed and persistent.
		em.getTransaction().commit();

		System.out.println("Added one student to database.");
		em.close();
		factory.close();//Close an application-managed entity manager.
	}
}

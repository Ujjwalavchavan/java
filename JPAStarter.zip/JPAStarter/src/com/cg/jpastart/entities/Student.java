package com.cg.jpastart.entities;
import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity//compulsory annotation
@Table(name="students")//optional annotation use when class and table name are different
public class Student implements Serializable {
	
	
	private static final long serialVersionUID = 1L;
	@Id//compulsory annotation
	
	//if this line is states that hibernet will generate the value
	//it is optional
	//hibernet_sequence: default value for oracle db
	@GeneratedValue(strategy=GenerationType.AUTO)//apply sequence generating strategy according to the db used
	
	
	private int studentId;
	
	/*it is needed when column name and class property name is not same 
	 but only before execution of the program i.e creation of the table 
	 as once table is created and we execute it then we will end up having two columns in the table*/
	//@Column(name = "name",length=10)
	@Column(length=10)
	//adjust the lenght of studentName from 255 char to 10 char
	private String studentName;
	public int getStudentId() {
		return studentId;
	}
	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String name) {
		this.studentName = name;
	}
}

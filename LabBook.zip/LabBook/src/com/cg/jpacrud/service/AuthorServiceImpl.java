package com.cg.jpacrud.service;

import com.cg.jpacrud.dao.AuthorDao;
import com.cg.jpacrud.dao.AuthorDaoImpl;
import com.cg.jpacrud.entities.Author;

public class AuthorServiceImpl implements AuthorService{
	
	AuthorDao authorDao = new AuthorDaoImpl();
	
	public AuthorServiceImpl() {
//		authorDao = new AuthorDaoImpl();
	}

	@Override
	public void insert(Author author) {
		try {
			authorDao.beginTransaction();
			authorDao.insert(author);
			authorDao.commitTransaction();
		} catch (Exception e) {
			authorDao.rollBackTransaction();
		}
	}

	@Override
	public void update(Author author) {
		try {
			authorDao.beginTransaction();
			authorDao.update(author);
			authorDao.commitTransaction();
		} catch (Exception e) {
			authorDao.rollBackTransaction();
		}
		
	}

	@Override
	public void delete(Author author) {
		try {
			authorDao.beginTransaction();
			authorDao.delete(author);
			authorDao.commitTransaction();
		} catch (Exception e) {
			authorDao.rollBackTransaction();
		}
	}

	@Override
	public Author findById(int id) {
		Author author= authorDao.findById(id);
		return author;
	}

}

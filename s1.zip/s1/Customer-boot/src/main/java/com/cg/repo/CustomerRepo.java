package com.cg.repo;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.cg.entity.Customer;

public interface CustomerRepo extends CrudRepository<Customer, Integer> {

	
	
}

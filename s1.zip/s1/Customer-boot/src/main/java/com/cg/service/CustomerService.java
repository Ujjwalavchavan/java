package com.cg.service;

import java.util.List;

import com.cg.entity.Customer;

public interface CustomerService {
	
    void saveCustomer(Customer c);
	
	Customer get(int id);
	
	Iterable<Customer> getAll();
	
	public String deleteProduct(int id);

	public Customer update(Customer c, int id);
	
}

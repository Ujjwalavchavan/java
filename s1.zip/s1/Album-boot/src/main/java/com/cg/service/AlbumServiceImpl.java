package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entity.Album;
import com.cg.exception.AlbumNotFoundException;
import com.cg.repo.AlbumRepoInterface;
@Transactional
@Service("service")
public class AlbumServiceImpl implements AlbumService {
	

		@Autowired
		private AlbumRepoInterface albumRepoInterface;
		
	@Override
	public void saveAlbum(Album album) {
	albumRepoInterface.save(album);
		
	}

	@Override
	public Album getAlbum(int albumId)throws AlbumNotFoundException {
		try {
			return albumRepoInterface.findById(albumId).get();
		} catch (Exception e) {
		
			throw new AlbumNotFoundException("No Album Found"+albumId);}
		
	}

	@Override
	public Album updateAlbum(Album album, int albumId) {
		album.setAlbumId(albumId);
		albumRepoInterface.save(album);
		return album;
	}

	@Override
	public String deleteAlbum(int albumId) {
		Album album = albumRepoInterface.findById(albumId).get();
		albumRepoInterface.delete(album);
	    return "Delete Successfully";
	}

//	@Override
//	public Iterable<Album> fetchAllAlbum() {
//		
//		return albumRepoInterface.findAll();
//	}

}
package com.cg.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.Album;
import com.cg.exception.AlbumNotFoundException;
import com.cg.service.AlbumService;

@RestController
public class AlbumController {
@Autowired 
private AlbumService albumService;


@PostMapping("/add")
public void saveAlbum(@RequestParam("albumtitle")String albumtitle,@RequestParam("albumartist")
String albumartist,@RequestParam("price")double price) {
	Album album=new Album();
	album.setAlbumTitle(albumtitle);
	album.setAlbumArtist(albumartist);
	album.setPrice(price);
	System.out.println("Saved Successfully");
	
}

@GetMapping(name="/album",produces="application/json")
public Album getAlbum(@RequestParam("albumid") int albumId) {
	Album album = null;
	try {
		album = albumService.getAlbum(albumId);
	} catch (AlbumNotFoundException e) {
		
		System.out.println("Album not found");
	}
	return album;
}

//@GetMapping("/all")
//public Iterable<Album> getAll() {
//	return albumService.fetchAllAlbum();
//}

@PutMapping(path ="/update/{id}", consumes = "application/json")
public Album update(@PathVariable("id") int id, @RequestBody Album album) {
	return albumService.updateAlbum(album, id);
}

@DeleteMapping(path ="/delete/{id}")
public String deleteAlbum(@PathVariable("albumId") int albumId) {
	return albumService.deleteAlbum(albumId);
}
}

package com.cg.service;

import com.cg.entity.Album;
import com.cg.exception.AlbumNotFoundException;

public interface AlbumService {
	void saveAlbum(Album album);

	Album getAlbum(int albumId) throws AlbumNotFoundException;

	Album updateAlbum(Album album, int albumId);
	
	String deleteAlbum(int albumId);
	
//	Iterable<Album> fetchAllAlbum();

}

package com.cg.exception;

public class AlbumNotFoundException extends Exception{
	public AlbumNotFoundException()
	{
		
	}
	public AlbumNotFoundException(String message)
	{
		super(message);
	}

}

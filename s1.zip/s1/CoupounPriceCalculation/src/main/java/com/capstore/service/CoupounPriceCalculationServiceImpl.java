package com.capstore.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.capstore.bean.Coupon;
import com.capstore.bean.Inventory;
import com.capstore.bean.Promo;
import com.capstore.repo.CoupounPriceCalculationRepo;

@Repository
@Transactional
public class CoupounPriceCalculationServiceImpl implements CoupounPriceCalculationService {

	@Autowired
	CoupounPriceCalculationRepo repoInterface;

	Inventory inventory;
	Promo promo;
	Coupon couponInfo;

	double finalAmount;
	double discountAmount;
	double couponPrice;

	@Override
	public double CouponCalculation(double price, double discountPrice) {
		couponPrice = price - discountPrice;
		return couponPrice;
	}

}

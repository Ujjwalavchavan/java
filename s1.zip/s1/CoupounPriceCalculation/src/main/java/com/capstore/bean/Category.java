/*
 * Author :- Mayuresh Shinde 173560
 * version:- 1.0.2
 */
package com.capstore.bean;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name = "category")
public class Category {
	@Id
	@Column(name = "category_id", length = 10)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "category_seq")
	@SequenceGenerator(name = "category_seq", sequenceName = "category_seq")
	private int id;

	@Column(name = "category_name", length = 50)
	private String name;

	@Column(name = "category_type", length = 50)
	private String type;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	@JsonIgnore
	public List<Product> getProduct() {
		return productFromCategory;
	}

	public void setProduct(List<Product> product) {
		this.productFromCategory = product;
	}

	public void addProduct(Product product) {
		product.setCategory(this);
		this.getProduct().add(product);
	}

	
	@Override
	public String toString() {
		return "Category [id=" + id + ", name=" + name + ", type=" + type + "]";
	}


	/************** Relationships ******************/

	@JsonIgnore
	@JsonManagedReference(value="product-category")
	@OneToMany(mappedBy = "categoryFromProduct", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	private List<Product> productFromCategory = new ArrayList<Product>();
}
/*
 * Author :- Mayuresh Shinde 173560
 * version:- 1.0.2
 */
package com.capstore.bean;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name = "merchant")
public class Merchant {

	@Id
	@Column(name = "merchant_id", length = 10)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "merchant_seq")
	@SequenceGenerator(name = "merchant_seq", sequenceName = "merchant_seq")
	private int id;

	@Column(name = "merchant_firstname", length = 25)
	private String firstName;

	@Column(name = "merchant_lastname", length = 25)
	private String lastName;

	@Column(name = "merchant_email", length = 64)
	private String email;

	@Column(name = "merchant_password", length = 50)
	private String password;

	@Column(name = "merchant_contact")
	private String contact;

	@Column(name = "is_merchant_activated", length = 3)
	private String isActive;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	@JsonIgnore
	public List<Inventory> getInventory() {
		return Inventory;
	}

	public void setInventory(List<Inventory> inventory) {
		Inventory = inventory;
	}

	public void addInventory(Inventory inventory) {
		inventory.setMerchant(this);
		this.getInventory().add(inventory);
	}

	/************** Relationships ******************/
	@JsonManagedReference(value = "merchant-inventory")
	@OneToMany(mappedBy = "merchant", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	private List<Inventory> Inventory = new ArrayList<Inventory>();
}
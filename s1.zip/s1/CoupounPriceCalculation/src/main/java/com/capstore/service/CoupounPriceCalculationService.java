package com.capstore.service;

public interface CoupounPriceCalculationService {

	// calculating coupon discount on an product
	double CouponCalculation(double price,double discountPrice);
	
	
}

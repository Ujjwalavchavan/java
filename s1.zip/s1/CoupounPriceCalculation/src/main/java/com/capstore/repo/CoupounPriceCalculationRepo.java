package com.capstore.repo;
/**
 * This is a Repo class for CouponPriceCalculation
 * @author Ujjwala Chavan
 * @version 1.0
 */
import org.springframework.data.repository.CrudRepository;

import com.capstore.bean.Promo;

public interface CoupounPriceCalculationRepo extends CrudRepository<Promo, Long> {

}

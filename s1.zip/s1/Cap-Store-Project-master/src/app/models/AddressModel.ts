export class AddressModel {
    id:number;
    addLine1: String;
    addLine2: String;
    state: String;
    city: String;
    postalCode:number;
}
export class Inventory{
    public id:number;
    public description:string;
    public price:number;
    public quantity:number;
}
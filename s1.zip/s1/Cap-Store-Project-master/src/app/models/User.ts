export class UserModel {

     currentPassword: string;
     newPassword: string;
     confirmPassword: string;
}

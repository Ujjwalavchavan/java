import { Inventory } from './InventoryModel';

export class Product {
    id: number;
    name: string;
    brand:string;
    inventoryFromProduct:Inventory[];
    
}
export class PayModel{
    public cardNumber:number;
    public custId:number;
    public cvv:number;
    public month:number;
    public year:number;
    public cardHolder:string;
    public status:boolean=false;
}
export class NewPassword {
    newPassword: string;
    confirmPassword: string;
}

import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../services/service.service';
import { EditCustomer } from './../models/editcustomer';
import { FormControl, Validators, FormGroup } from '@angular/forms';
import * as sha1 from 'sha1/sha1';

@Component({
  selector: 'app-edit-customer',
  templateUrl: './edit-customer.component.html',
  styleUrls: ['./edit-customer.component.css']
})

export class EditCustomerComponent implements OnInit {
  editcustomer: EditCustomer;
  conversionEncryptOutput: string;
  myForm: FormGroup;
  constructor(private service: ServiceService) {
    this.editcustomer = new EditCustomer();
  }


  email = new FormControl('', [Validators.required, Validators.email]);
  passwordControl = new FormControl('', [
    Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{8,}')]);
  repeatPasswordControl = new FormControl('', []);


  ngOnInit() {
  }

  getErrorMessage() {
    return this.email.hasError('required')
      ? 'Email is required'
      : this.email.hasError('email')
      ? 'Not a valid email'
      : '';
  }
  validateboth() {
    if (this.editcustomer.password !== '') {
      if (this.editcustomer.password === this.editcustomer.repeatpassword) {
        // password matches
      } else {
        this.repeatPasswordControl.setErrors(Validators.requiredTrue);
      }
    }
  }
  storeDetails() {
    this.conversionEncryptOutput = sha1(this.editcustomer.password);
    this.editcustomer.password = this.conversionEncryptOutput;
    this.editcustomer.repeatpassword = this.conversionEncryptOutput;
    this.service.edit(this.editcustomer).subscribe(
      result => {
        console.log(result);
      },
      error => {
        console.log(error);
      }
    );
  }
}

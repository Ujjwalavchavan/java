import { CartService } from './../services/cart.service';
import { Component, OnInit } from '@angular/core';
import { Product } from '../models/Product';

@Component({
  selector: 'app-wishlist',
  templateUrl: './wishlist.component.html',
  styleUrls: ['./wishlist.component.css']
})
export class WishlistComponent implements OnInit {

  wishList: Product[] = []
  constructor(private cartService: CartService) { }
  ngOnInit() {
    this.getAll();
  }


  getAll() {
    this.cartService.getWishList().subscribe(
      res => {
      this.wishList = res
      }, err => {
        console.log(err)
      }
    )
  }
}

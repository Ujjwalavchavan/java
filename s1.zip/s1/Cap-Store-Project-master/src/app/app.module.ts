import { AdminModule } from './admin/admin.module';
import { MaterialModule } from './material.module';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { HomeComponent } from './home/home.component';
import { CarouselModule } from 'ngx-bootstrap/carousel';
import { ProductComponent } from './product/product.component';
import { ReviewComponent } from './review/review.component';
import { CartComponent } from './cart/cart.component';
import { WishlistComponent } from './wishlist/wishlist.component';
import { CheckoutComponent } from './checkout/checkout.component';
import { AddressComponent } from './address/address.component';
import { CouponsComponent } from './coupons/coupons.component';
import { PaymentComponent } from './payment/payment.component';
import { CustomerPageComponent } from './customer-page/customer-page.component';
import { EditCustomerComponent } from './edit-customer/edit-customer.component';
import { RegisterComponent } from './register/register.component';
import { LogonComponent } from './logon/logon.component';
import { HttpClientModule } from '@angular/common/http';
import { ChangepasswordComponent } from './changepassword/changepassword.component';
import { ForgotpasswordComponent } from './forgotpassword/forgotpassword.component';
import { NewpasswordComponent } from './newpassword/newpassword.component';
import { InvoiceComponent } from './invoice/invoice.component';
import { ShippingComponent } from './shipping/shipping.component';
import { SearchComponent } from './search/search.component';
import { CategoryComponent } from './category/category.component';
@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    ProductComponent,
    ReviewComponent,
    CartComponent,
    WishlistComponent,
    CheckoutComponent,
    AddressComponent,
    CouponsComponent,
    PaymentComponent,
    CustomerPageComponent,
    EditCustomerComponent,
    RegisterComponent,
    LogonComponent,
    ChangepasswordComponent,
    NewpasswordComponent,
    ForgotpasswordComponent,
    InvoiceComponent,
    ShippingComponent,
    SearchComponent,
    CategoryComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    MaterialModule,
    CarouselModule,
    HttpClientModule,
    AdminModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

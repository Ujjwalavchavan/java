import { Order } from './../models/OrderModel';
import { PayModel } from './../models/pay';
import { AddressModel } from './../models/AddressModel';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CheckoutService {

  baseHref = 'http://localhost:8888';


  constructor(private http: HttpClient) { }

  public cartId:number=0;
  public addId:number=0;
  public merchantId:number=0;
  public totalAmount:number=0;
  
  getAddress(id:number)
  {
    return this.http.get<AddressModel[]>(this.baseHref+"/customer/getaddress/"+id);
  }

  setAddress(id:number,address:AddressModel)
  {
    var body = {
      addLine1:address.addLine1,
      addLine2:address.addLine2,
      state:address.state,
      city:address.city,
      postalCode:address.postalCode
    }
    return this.http.post<AddressModel>(this.baseHref+"/customer/address/"+id,body)
  }

  getCoupons()
  {
    return this.http.get(this.baseHref)
  }

  setCardDetails(payment:PayModel)
  {
      var body ={
        cardNumber:payment.cardNumber,
        cardHolder:payment.cardHolder,
        month:payment.month,
        year:payment.year,
        cvv:payment.cvv,
        custId:JSON.parse(localStorage.getItem("user"))["id"]
      }
      console.log(body)
      return this.http.post<PayModel>(this.baseHref + "/card/add",body);
  }

  placeOrder()
  {
    console.log(this.cartId)
    console.log(this.addId)
    console.log(this.merchantId)
    console.log(this.totalAmount)   
    return this.http.post(this.baseHref+"/order/checkout/"+this.cartId+"/"+this.addId+"/"+this.merchantId+"/"+this.totalAmount,{}); 
  }

  getOrders()
  {
    return this.http.get<Order[]>(this.baseHref+"/order/"+JSON.parse(localStorage.getItem("user"))["id"]);
  }
}
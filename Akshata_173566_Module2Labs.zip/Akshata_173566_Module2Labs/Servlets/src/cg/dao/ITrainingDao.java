package cg.dao;

import java.util.List;

import cg.bean.TrainingBean;

public interface ITrainingDao {
	TrainingBean enroll(TrainingBean training);
	List<TrainingBean> showAll();
	
	String ALLDATA = "Select * From training";
}

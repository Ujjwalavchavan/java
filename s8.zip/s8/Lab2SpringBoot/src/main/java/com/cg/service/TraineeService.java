package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.dao.ITrainee;
import com.cg.entity.Trainee;

@Repository
@Transactional
public class TraineeService implements InterfaceTraineeService {

	@Autowired
	ITrainee dao;
	
	@Override
	public void saveTrainee(Trainee t) {
		dao.save(t);
	}

	@Override
	public Trainee getTrainee(int id) {
		return dao.findById(id).get();
	}

	@Override
	public Iterable<Trainee> getAll() {
		return dao.findAll();
	}

	@Override
	public String deleteTrainee(Trainee t1) {
		dao.delete(t1);
		return "Delete Successfully";
	}

	@Override
	public Trainee updateTrainee(Trainee t, int id) {
		t.setTraineeId(id);
		dao.save(t);
		return t;
	}	
}

import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { ToDoModel } from '../models/Todo';
import { ToDoAppService } from '../services/to-do-app.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent  {
    //to create new entry
    @Input() todo: ToDoModel;

    //to control update button in form
    @Input() isEditing: boolean;

    //to control the edit event
    @Output() edited = new EventEmitter();

    //Initilizing using constructor
    constructor(private todoService: ToDoAppService) {
    this.todo = new ToDoModel();
    }

    //Method to add data
    add() {
      this.todoService.add(this.todo);
      this.todo = new ToDoModel();
    }
    //method to update data  
    update(){
      this.isEditing = false;
      this.todo = new ToDoModel();
      this.edited.emit();
    }
}//End of LoginComponent class

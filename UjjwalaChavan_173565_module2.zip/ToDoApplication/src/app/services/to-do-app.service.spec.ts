import { TestBed } from '@angular/core/testing';

import { ToDoAppService } from './to-do-app.service';

describe('ToDoAppService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ToDoAppService = TestBed.get(ToDoAppService);
    expect(service).toBeTruthy();
  });
});

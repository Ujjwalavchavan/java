import { Injectable } from '@angular/core';
import { ToDoModel } from '../models/Todo';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class ToDoAppService {

  //creating array of type ToDoModel
  todoArr: ToDoModel[];

  //creating constructor for mentioning router
  constructor(private routes:Router) {
    this.todoArr = [];
  }

  //method for pushing data into array
  add(todo: ToDoModel) {
    this.todoArr.push(todo);
    this.routes.navigate(['/display']);
  }

  //method for displaying content from the array
  getToDo() {
    return this.todoArr;
  }

  //method for deleting content from the array
  delete(index: number) {
    this.todoArr.splice(index, 1);
  }
  
  //method for performing edit mechanism on the array
  edit(id: number) {
    //return this.todoArr.find();
  }
}//End of the ToDoAppService class
export class ToDoModel //Class containing data members 
{
   //Variable declaration
   public emailAddress:string;
   public password:string;
   public task:string;
}
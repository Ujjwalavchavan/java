import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { TodoComponent } from './todo/todo.component';

//creating Routes for the Components
const routes: Routes = [
  { path: '', redirectTo: 'Home', pathMatch: 'full' },
  { path: 'Home', component: HomeComponent, pathMatch: 'full' },
  { path: 'Login', component: LoginComponent, pathMatch: 'full', },
  { path: 'Todo', component: TodoComponent, pathMatch: 'full' },
  { path: '**', redirectTo: 'Home', pathMatch: 'full' }
];
@NgModule({
  //Mentioning imports and exports for RouterModule
  imports: [RouterModule.forRoot(routes),
    CommonModule],
  exports: [RouterModule],
  declarations: []
})
export class AppRoutingModule { }

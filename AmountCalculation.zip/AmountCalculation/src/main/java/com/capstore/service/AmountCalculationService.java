package com.capstore.service;

public interface AmountCalculationService {

	// calculating discount on an product
	double PromoCalculation(double price,double discountAmount);

	// calculating coupon discount on an product
	double CouponCalculation(double price,double discountPrice);
	
	
}

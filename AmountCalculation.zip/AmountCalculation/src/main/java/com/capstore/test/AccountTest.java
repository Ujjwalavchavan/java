package com.capstore.test;

import org.junit.Test;

import com.capstore.bean.Coupon;
import com.capstore.bean.Inventory;
import com.capstore.bean.Promo;
import com.capstore.service.AmountCalculationServiceImpl;

public class AccountTest {


		Coupon coupon;
		Promo promo;
		Inventory inventory;
		AmountCalculationServiceImpl service =new AmountCalculationServiceImpl();
	
		@Test
		public void calculateCoupon()
		{
			coupon.setIsUsed("yes");
			inventory.setPrice(1000);
			coupon.setDiscountPrice(200);
			service.CouponCalculation(inventory.getPrice(),coupon.getDiscountPrice());
		}
		@Test
		public void calculatePromo()
		{

			inventory.setPrice(1000);
			promo.setDiscountAmount(30);
			service.PromoCalculation(inventory.getPrice(), promo.getDiscountAmount());
		}
	}

	
	
	

